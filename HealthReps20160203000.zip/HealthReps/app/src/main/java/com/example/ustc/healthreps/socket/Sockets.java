package com.example.ustc.healthreps.socket;

//公共TCPSocket
public class Sockets {
	public static final TCPSocket socket_center = new TCPSocket();
}
