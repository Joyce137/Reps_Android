package com.example.ustc.healthreps.health.view;

public interface OnProgressListener {

    public void onProgress(int progress); 
    
    public void onComplete(int progress); 

}
