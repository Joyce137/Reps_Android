package com.example.ustc.healthreps.ui;

import android.app.ListActivity;

/**
 * Created by CaoRuijuan on 2/2/16.
 */
public class VideoActivity extends ListActivity {

}
