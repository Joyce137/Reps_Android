package com.example.ustc.healthreps.sms;

/**
 * Created by CaoRuijuan on 1/26/16.
 */
public class SMS {
    public static String APPKEY = "f29e0be3a2a0";
    public static String APPPSECRET = "7087b12d535d0ce7d684bd37e92f9b7e";
}
