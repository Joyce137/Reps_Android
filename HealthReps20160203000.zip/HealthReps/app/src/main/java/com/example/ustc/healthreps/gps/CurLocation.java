package com.example.ustc.healthreps.gps;

/**
 * Created by CaoRuijuan on 1/9/16.
 */
public class CurLocation {
    //经度
    public static double lontitude;
    //纬度
    public static double latitude;
    //城市
    public static String city;
}
