package com.joyce.reps.serverInterface;

//Mod_PASSWORD  ---修改密码
public class ModPassword {
	byte[] name = new byte[30];
	byte[] oldPwd = new byte[30];
	byte[] newPwd = new byte[30];
}