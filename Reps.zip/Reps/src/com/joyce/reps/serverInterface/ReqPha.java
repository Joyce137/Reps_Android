package com.joyce.reps.serverInterface;

//ReqPha
public class ReqPha {
	byte[] phaName = new byte[12];
	byte[] realName = new byte[20];
}
