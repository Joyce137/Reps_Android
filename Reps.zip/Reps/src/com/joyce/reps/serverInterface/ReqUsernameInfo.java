package com.joyce.reps.serverInterface;

//Req_Info_Username
public class ReqUsernameInfo {
	byte[] username = new byte[12];
}