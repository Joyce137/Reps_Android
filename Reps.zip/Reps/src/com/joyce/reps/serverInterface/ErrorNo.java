package com.joyce.reps.serverInterface;

//ERRORNO错误标志
public class ErrorNo {
	public static final int SOCKET_NULL = 0X0301;
	public static final int WSAEWOULDBLOCK = 0x0302;
	public static final int DATA_NULL = 0x0303;
	public static final int MINUSVALUE = 0x0304;
}
