package com.joyce.reps.serverInterface;

//ReqDoc
public class ReqDoc {
	byte[] docName = new byte[12];
	byte[] realName = new byte[20];
}
