package com.joyce.reps.serverInterface;

//P2PInfo  ---聊天消息
public class P2PInfo {
	byte[] username = new byte[12];
	byte[] toUsername = new byte[12];
	byte[] info = new byte[200];
}
