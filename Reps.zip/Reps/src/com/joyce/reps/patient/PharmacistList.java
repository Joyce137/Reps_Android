package com.joyce.reps.patient;

import com.joyce.reps.R;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;

public class PharmacistList extends Activity {

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.Activity#onCreate(android.os.Bundle)
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_pharmacistlist);

	}

}
