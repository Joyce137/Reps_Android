package com.example.ustc.healthreps.health;

import android.app.Activity;
import android.os.Bundle;

import com.example.ustc.healthreps.R;

/**
 * Created by HBL on 2015/11/10.
 */
public class DeviceListActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_list);
    }
}
