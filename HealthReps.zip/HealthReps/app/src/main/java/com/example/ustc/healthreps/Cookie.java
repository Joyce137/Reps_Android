package com.example.ustc.healthreps;

/**
 * Created by CaoRuijuan on 12/9/15.
 */
public class Cookie {
}
