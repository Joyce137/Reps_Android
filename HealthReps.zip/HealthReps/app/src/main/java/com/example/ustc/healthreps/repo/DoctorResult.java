package com.example.ustc.healthreps.repo;

/**
 * Created by CaoRuijuan on 12/21/15.
 */
public class DoctorResult {

}
