package com.example.ustc.healthreps.model;

/**
 * Created by CaoRuijuan on 12/8/15.
 */
public class DocPha {
    public String username;
    public String keshi;
    public String zhicheng;
    public String status;
    public String realname;
}
