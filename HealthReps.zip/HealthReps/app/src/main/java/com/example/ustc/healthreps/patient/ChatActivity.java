package com.example.ustc.healthreps.patient;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.example.ustc.healthreps.MainActivity;
import com.example.ustc.healthreps.R;
import com.example.ustc.healthreps.model.Users;
import com.example.ustc.healthreps.serverInterface.NetPack;
import com.example.ustc.healthreps.serverInterface.P2PInfo;
import com.example.ustc.healthreps.serverInterface.Types;
import com.example.ustc.healthreps.socket.Sockets;

import java.io.UnsupportedEncodingException;

/**
 * Created by CaoRuijuan on 12/9/15.
 */
public class ChatActivity extends MainActivity{
    public static Handler sChatHandler = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.doctor_session);
        initView();
    }

    //初始化界面
    public void initView(){
        sChatHandler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                NetPack data = (NetPack) msg.obj;
                onRecvChatMsg(data);
            }
        };
    }

    //发送消息
    public void sendMsgToSomebody(String username,String msg){
        P2PInfo info = new P2PInfo();
        try{
            info.username = Users.sLoginUsername.getBytes("GBK");
            info.toUsername = username.getBytes("GBK");
            info.info = msg.getBytes("GBK");
        }catch(UnsupportedEncodingException e){
            e.printStackTrace();
        }

        NetPack p = new NetPack(-1,P2PInfo.SIZE, Types.ForwardInfo,info.getP2PInfoByte());
        p.CalCRC();
        Sockets.socket_center.sendPack(p);
    }


    //接收消息
    public void onRecvChatMsg(NetPack pack){
        P2PInfo info = P2PInfo.getP2PInfo(pack.getM_buffer());
    }
}
