package com.example.ustc.healthreps.repo;

import android.os.Handler;

/**
 * Created by CaoRuijuan on 1/13/16.
 */
public class FileRepo {
    public static Handler sFileRepoControlmsgHandler = null;

}
