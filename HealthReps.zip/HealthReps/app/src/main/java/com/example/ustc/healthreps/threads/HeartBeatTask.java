package com.example.ustc.healthreps.threads;

import java.util.TimerTask;

import android.util.Log;

import com.example.ustc.healthreps.model.Users;
import com.example.ustc.healthreps.repo.LoginRepo;
import com.example.ustc.healthreps.socket.Sockets;
import com.example.ustc.healthreps.socket.TCPSocket;
import com.example.ustc.healthreps.serverInterface.Types;

//心跳包任务
public class HeartBeatTask extends TimerTask{
	//String jobName = "HeartBeatTask";
	TCPSocket mSocket = Sockets.socket_center;
	
	@Override
	public void run() {
		Log.e("HeartBeatTask", "run()");
		HeartBeatTimeProc();
	}
	
	//心跳包执行动作
	public void HeartBeatTimeProc(){
		mSocket.sendHeartBeat();
		//synchronized (lock) {
			LoginRepo.mBeatTimes++;
			if(LoginRepo.mBeatTimes <= 2){
					//m_connect_alert.setBackgroundColor(color.green);
				System.out.println(LoginRepo.mBeatTimes+"-----color.green");
				if(LoginRepo.mBeatTimes == 2){
					mSocket.sendHeartBeat();
				}
			}
			else if(LoginRepo.mBeatTimes == 3 || LoginRepo.mBeatTimes == 4){
				//m_connect_alert.setBackgroundColor(color.yellow);
				System.out.println(LoginRepo.mBeatTimes+"-----color.yellow");
				mSocket.sendHeartBeat();
			}
			else if(LoginRepo.mBeatTimes >= 5){
				Users.sOnline = false;
				//m_connect_alert.setBackgroundColor(color.red);
				System.out.println(LoginRepo.mBeatTimes + "-----color.red");
				mSocket.shutSocket();

		        if (mSocket.initSocket(Types.center_Port, Types.version_IP))
		        {
		        	mSocket.reLogin(Users.sLoginUsername);
		        }
			}
		//}
	}
}