package com.example.ustc.healthreps.ui;

import android.support.v4.app.Fragment;

/**
 * Created by CaoRuijuan on 1/12/16.
 */
public class Fragments {
    public static Fragment curFragment;

}
