package com.joyce.login;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

import com.liwei.uiversion1.MyCamera;
import com.liwei.uiversion1.R;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class FileTest extends Activity{
	public Button mLoadbtn,mSendbtn,mRecvbtn,mPhotobtn;
	public TextView mTypetv,mFilePathtv;
	public int mFileType = Types.FILE_TYPE_PIC_REG;			//文件类型---默认为资质图片
	public String mFilePath;			//文件路径
	public TCPSocket mFileSocket = Sockets.socket_center;
	static private int openfileDialogId = 0;
	public static ReceiveMessageThread recv = null;
	public static SendFileThread mSendFileThread = null;
	
	
	//InitSocket
	public boolean InitSocket(int DefaultPort, String DefaultIP){
		Log.e("InitSocket", "0");
		InetAddress addr = null;
		try {
			Log.e("InitSocket", "1");
			addr = InetAddress.getByName(DefaultIP);
			mFileSocket.sockClient = new Socket(addr, DefaultPort);
			
			return true;
		} catch (UnknownHostException e) {
			Log.e("InitSocket", "2");
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			Log.e("InitSocket", "3");
			e.printStackTrace();
			return false;
		}
	}
		
	public void initSocket() {
		 if (!InitSocket(Types.center_Port, Types.version_IP))
		        if (!InitSocket(Types.center_Port, Types.version_IP))
		            if (!InitSocket(Types.center_Port, Types.version_IP))
		            {
		                System.out.println("网络故障，请稍后重试");
		                return;
		            }
		 Log.e("initSocket", "initSocket成功！");
	}	
	
//	public FileTest(int type){
//		this.mFileType = type;
//	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		//安卓2.3以后访问网络增加内容
		StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
				.detectDiskReads()
				.detectDiskWrites()
				.detectNetwork()
				.penaltyLog()
				.build()); 
		StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
				.detectLeakedSqlLiteObjects()
				.detectLeakedClosableObjects()
				.penaltyLog()
				.penaltyDeath()
				.build());
		
		//初始化
		initView();
		//初始化Socket
		initSocket();
		//启动接收线程
		if(recv == null){
			MainActivity main = null;
			recv = new ReceiveMessageThread("Recv_Thread");
//			Thread th = new Thread(recv);
			recv.start();
		}
		
		//开启发文件线程
		if(mSendFileThread == null){
			mSendFileThread = new SendFileThread();
			mSendFileThread.start();
		}
		else{
			Toast.makeText(getApplication(), "mThread已经start", Toast.LENGTH_LONG).show();
		}
		
		System.out.println("Main Thread.....");
		
		if(!(MyCamera.cameraIntent == null)){
			Intent cintent = MyCamera.cameraIntent;
			Bundle cbundle = cintent.getExtras();
			mFilePathtv.setText(cbundle.getString("photoPath"));
		}
		
		mLoadbtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				System.out.println("loadFile");
				loadFile();
			}
		});
		
		mSendbtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				sendFile();
			}
		});
		
		mRecvbtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				recvFile();
			}
		});
		mPhotobtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(FileTest.this, MyCamera.class);
		    	finish();
				startActivity(intent);
			}
		});
	}
	//初始化界面
	public void initView(){
		//view 
		mLoadbtn = (Button) findViewById(R.id.loadbtn);
		mSendbtn = (Button) findViewById(R.id.sendbtn);
		mRecvbtn = (Button) findViewById(R.id.recvbtn);
		mTypetv = (TextView) findViewById(R.id.fileTypetv);
		mFilePathtv = (TextView) findViewById(R.id.filepathtv);
		mPhotobtn = (Button)findViewById(R.id.takePhotobtn);
		
		mFilePath = "";	
		if(mFileType == Types.FILE_TYPE_DOCPHA_STAMP){
			mTypetv.setText("个人签章");
		}
		else if(mFileType == Types.FILE_TYPE_PIC_REG){
			mTypetv.setText("资质图片");
		}
		else{
			System.out.println("FileType:"+mFileType);
			mTypetv.setText("普通文件");
		}
	}
	//加载文件路径
	public void loadFile() {
		mFilePath = chooseFile(mFileType);
		int len = mFilePath.length();
		if(mFilePath.length() != 0){
			mFilePathtv.setText(mFilePath);
		}
	}
	//选择文件
	public String chooseFile(int type){
		String strFile = "";
		//个人签章
		if(mFileType == Types.FILE_TYPE_DOCPHA_STAMP){
			
		}
		//资质图片
		else if(mFileType == Types.FILE_TYPE_PIC_REG){
			showDialog(openfileDialogId); 
		}
		//普通文件
		else{
			
		}
		return strFile;
	}
	
	//打开文件选择器
	@Override
	protected Dialog onCreateDialog(int id) {  
        if(id==openfileDialogId){  
            Map<String, Integer> images = new HashMap<String, Integer>();  
            // 下面几句设置各文件类型的图标， 需要你先把图标添加到资源文件夹  
            images.put(OpenFileDialog.sRoot, R.drawable.hdd);   // 根目录图标  
            images.put(OpenFileDialog.sParent, R.drawable.open);    //返回上一层的图标  
            images.put(OpenFileDialog.sFolder, R.drawable.folder);   //文件夹图标  
            images.put("jpg", R.drawable.file_jpg);   //jpg文件图标  
            images.put("png", R.drawable.file_png);   //png文件图标
            images.put("gif", R.drawable.file_gif);   //gif文件图标
            images.put(OpenFileDialog.sEmpty, R.drawable.hdd);  
            Dialog dialog = OpenFileDialog.createDialog(id, this, "打开文件", new CallbackBundle() {  
                @Override  
                public void callback(Bundle bundle) {  
                    String filepath = bundle.getString("path");  
                    mFilePathtv.setText(filepath); // 把文件路径显示在标题上  
                }  
            },   
            ".jpg;.png;.gif",  
            images);  
            return dialog;  
        }  
        return null;  
    }  
	
	//发送文件
	public void sendFile() {
		if(recv == null){
			MainActivity main = null;
			recv = new ReceiveMessageThread("Recv_Thread");
//			Thread th = new Thread(recv);
			recv.start();
		}
		
		//开启发文件线程
		if(mSendFileThread == null){
			mSendFileThread = new SendFileThread();
			mSendFileThread.start();
		}
	
		
		mFilePath = mFilePathtv.getText().toString();
		//mFilePath = "/sdcard/1445423658301.jpg";
		System.out.println("mFilePath"+mFilePath);
		if(mFilePath != null){		
			//发文件		
			if(mFileType == Types.FILE_TYPE_PIC_REG){
				String filename = "store1"+".jpg";
				mFileSocket.SendFile(mFilePath, filename, Types.MOD_FILE_TYPE_PIC_REG);
			}
		}
	}
	//SendFile_thread
	public boolean SendFileThread(String filepath, String filename, int type){
		if(type == Types.FILE_TYPE_PRES_CHECK || type == Types.FILE_TYPE_PRES_UNCHECK
				|| type == Types.FILE_TYPE_PRES_LOCAL_UNCHECK || type == Types.FILE_TYPE_PRES_CHECK_REJECT){
			mFileSocket.SendHeartBeat();
		}
		String random_str = Utils.getRandomStr();
		//判断文件是否存在并可读
		File f = new File(filepath);
		if(!f.exists()||!f.canRead()){
			return false;
		}
		
		//读取文件到filebuf中
		int size  =  (int) f.length();
		byte[] filebuf = new byte[size];
		//文件IO流
		FileInputStream reader = null;
		try {
			reader = new FileInputStream(f);
			reader.read(filebuf, 0, size);
			reader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	
		//文件拆包
		int packCount = 0;
		if(size % Types.FILE_MAX_BAG == 0){
			packCount = size / Types.FILE_MAX_BAG;
		}
		else{
			packCount = size / Types.FILE_MAX_BAG+1;
		}
		for(int i = 0;i<packCount;i++){
			//文件包设置
			FileInfo fpinfo = new FileInfo();
			fpinfo.filename = filename.getBytes();
			fpinfo.id = i+1;
			//文件结尾
			if(i == packCount - 1){
				fpinfo.flag = Types.FILEEND;
			}
			if(i == 0){
				fpinfo.flag = Types.FILESTRAT;
			}
			fpinfo.len = size;
			fpinfo.type = (short)type;
			fpinfo.start = i * Types.FILE_MAX_BAG;
			fpinfo.idnum = packCount;
			fpinfo.random_str = random_str.getBytes();
			if(i == packCount - 1){
				System.arraycopy(filebuf, i*Types.FILE_MAX_BAG,fpinfo.content, 0,  size - Types.FILE_MAX_BAG*i);
				fpinfo.content_len = (short) (size%Types.FILE_MAX_BAG);
			}
			else{
				System.arraycopy(filebuf, i*Types.FILE_MAX_BAG, fpinfo.content, 0, Types.FILE_MAX_BAG);
			}
			
			//封装成NET_PACK包
			NET_PACK p = new NET_PACK(-1,fpinfo.size,Types.FILETAG,fpinfo.getFileInfoBytes());
			p.size = NET_PACK.infoSize + fpinfo.size;
			p.CalCRC();
			
			//发送文件包
			//mFileSocket.SendPack(p);
			if(!mFileSocket.SendPack(p)){
				return false;
			}
		}
		return true;
	}
	//接收文件
	public void recvFile() {
		
	}
	//RecvPack
	public void RecvPack(NET_PACK data){
		Log.e("RecvPack", "RecvPack------");
		if(data.getM_nFlag() == Types.INFONOYES){
			doControlMsg(data);
		}
	}
	
	public void doControlMsg(NET_PACK data) {
		Control_Msg msg = Control_Msg.getControl_MsgInfo(data.getM_buffer());
		if(msg.getFlag() == Types.MOD_FILE_TYPE_PIC_REG)
		{
			onRecvControlMsg(msg);
		}
	}
	
	public void onRecvControlMsg(Control_Msg msg){
		if (msg.getFlag() == Types.MOD_FILE_TYPE_PIC_REG)
		{
			if (msg.isYesno())
			{
				Looper.prepare();
				Toast.makeText(getApplicationContext(), "资质图片上传成功！", Toast.LENGTH_SHORT).show();
				
				//关闭发送文件线程
				mSendFileThread.isTrue = false;
				mSendFileThread.interrupt();
				mSendFileThread = null; 
				
				//关闭接收线程
		        recv.isTrue = false;
		        recv.interrupt();
		        recv = null;  
		        
				Looper.loop();
			}
		}
	}
	
	//文件发送线程SendFileThread
	class SendFileThread extends Thread{
		boolean isTrue = true;
		public Handler mHandler = null; 
		@Override
		public void run() {
			TCPSocket pSocket = Sockets.socket_center;
			while(isTrue){
				synchronized (this) {
					try {
						this.wait(1);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				
				//建立消息循环
				Looper.prepare();//1、初始化Looper
	            mHandler  = new Handler(){//2、绑定handler到SendFileThread实例的Looper对象
	                @Override
					public void handleMessage (Message msg) {//3、定义处理消息的方法
	                    switch(msg.what) {
	                    case Types.MY_MSG:
	                    	PostThread p = (PostThread) msg.obj;
	                    	String filename = new String(p.filename);
	                    	String filepath = new String(p.filepath);
	                    	int type = p.type;
	                    	SendFileThread(filepath, filename, type);
	                    }
	                }
	            };
	            Looper.loop();//4、启动消息循环
			}		
		}
	};
	
	//接收线程
		class ReceiveMessageThread extends Thread{
			boolean isTrue = true;
			public ReceiveMessageThread(String threadName){
				this.setName(threadName);
			}
			@Override
			public void run() {
				Log.e("ReceiveMessageThread", "run() ");
				//_tagThreadParams_WORKER x = new _tagThreadParams_WORKER();
				TCPSocket p = Sockets.socket_center; //从主线程中传过来
				byte recvBuf[] = new byte[10000];
				boolean pack_err = false;
				boolean isPackageHead = false;   
					
				while(isTrue){
					synchronized (this) {
						try {
							this.wait(1);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					
					try {
						p.sockClient.getInputStream().read(recvBuf);
					} catch (IOException e) {
						e.printStackTrace();
					}
					System.out.println(recvBuf.length);
					System.out.println(pack_err);
					if(pack_err == false){
						if(isPackageHead == true){
							PackHead ph = PackHead.getPackHeadInfo(recvBuf);
							if(ph.getM_Start() == Types.PACK_START_FLAG){
								isPackageHead = false;
							}
							else{
								for(int i = 0;i<recvBuf.length;i++){
									recvBuf[i] = 0;
								}
								pack_err = true;
							}
						}
						else{
							NET_PACK data = NET_PACK.getNET_PACKInfo(recvBuf);
							if(data.VerifyCRC() == data.getM_Crc()){							
								RecvPack(data);		//交给RecvPack处理
								//将recvBuf清空
								for(int i = 0;i<recvBuf.length;i++){
									recvBuf[i] = 0;
								}
								pack_err = true;
							}
							else{
								//将recvBuf清空
								for(int i = 0;i<recvBuf.length;i++){
									recvBuf[i] = 0;
								}
								pack_err = true;
							}
						}
					}		
				}
			}
		};
}

