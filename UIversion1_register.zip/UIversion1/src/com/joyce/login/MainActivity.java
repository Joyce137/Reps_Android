package com.joyce.login;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Timer;
import java.util.TimerTask;

import com.liwei.uiversion1.MainFrame;
import com.liwei.uiversion1.R;
import com.liwei.uiversion1.R.color;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.StrictMode;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	//心跳包相关
	private static Object lock = new Object(); // static确保只有一把锁
	int m_beatTimes = 0;

	private Button loginBtn;
	private TextView mLogin_wangjimima, mLogin_zhuce;
	public TCPSocket login_socket = Sockets.socket_center;
	private String m_default_pha;
	public static String m_login_username;
	public ReceiveMessageThread recv = null;
	
	//声明一个Handler对象
	private Handler mHandler;
	
	//用户名和密码输入框
	private EditText mLogin_user, mLogin_password;
	//显示网络状况
	private Button m_connect_alert;
	
	public static Context context;
	
	public Register reg= new Register(); 

	//InitSocket
	public boolean InitSocket(int DefaultPort, String DefaultIP){
		Log.e("InitSocket", "0");
		InetAddress addr = null;
		try {
			Log.e("InitSocket", "1");
			addr = InetAddress.getByName(DefaultIP);
			login_socket.sockClient = new Socket(addr, DefaultPort);
			
			return true;
		} catch (UnknownHostException e) {
			Log.e("InitSocket", "2");
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			Log.e("InitSocket", "3");
			e.printStackTrace();
			return false;
		}
	}
		
	public void initSocket() {
		 if (!InitSocket(Types.center_Port, Types.version_IP))
		        if (!InitSocket(Types.center_Port, Types.version_IP))
		            if (!InitSocket(Types.center_Port, Types.version_IP))
		            {
		                System.out.println("网络故障，请稍后重试");
		                return;
		            }
		 Log.e("initSocket", "initSocket成功！");
	}
	
	//RecvPack
	public void RecvPack(NET_PACK data){
		Log.e("RecvPack", "RecvPack------");
		//登录标志
		if(data.getM_nFlag() == Types.Login_is){
			Login_Back_Info y = Login_Back_Info.getLogin_Back_Info(data.getM_buffer());
			if(y.getRecon() == Types.USER_LOGIN_FLAG){
				onRecvLoginMessage(data);
			}
		}
		else if(data.getM_nFlag() == Types.Reg_is){
			reg.showData(data);
		}
		else if(data.getM_nFlag() == Types.INFONOYES){
			doControlMsg(data);
		}
		else{
			onRecvNetPack(data);
		}
	}
	
	public void doControlMsg(NET_PACK data) {
		Control_Msg msg = Control_Msg.getControl_MsgInfo(data.getM_buffer());
		if(msg.getFlag() == Types.MOD_FILE_TYPE_PIC_REG){
			//onR
		}
	}

	//收到login登录结果信息
	public void onRecvLoginMessage(NET_PACK data){
		System.out.println("onRecvLoginMessage-----------");
		String login_result = "";
		Login_Back_Info y = Login_Back_Info.getLogin_Back_Info(data.getM_buffer());
		m_login_username = y.getUsername();
		m_default_pha = y.getPharmacist();
		login_socket.username = y.getUsername();
		boolean yesno = y.isYesno();
		if(yesno){
			//登录成功
			login_result = "yes";
			Log.e("onRecvLoginMessage: login_result", login_result);
	        	        
			Looper.prepare();
			//Toast.makeText(MainActivity.this, login_result, Toast.LENGTH_SHORT).show();
			Intent intent = new Intent(MainActivity.this, MainFrame.class);
			startActivity(intent);
	    	//关闭接收线程
	        recv.isTrue = false;
	        recv.interrupt();
	        recv = null;    
	        
//	        //待登录之后启动心跳包
//	        login_socket.SendHeartBeat();
//	        startHeartBeatThread();
	        Looper.loop();    	        
		}
		else{
			//1、登陆的时候 type = 1 密码和账号错误；type = 2 已经在线; type = 3 使用错了客户端; type = 4 审核未过
	        int type = y.getType();
	        switch (type)
	        {
	            case 1:
	                login_result = "账号或者密码错误";
	                break;
	            case 2:
	            	login_result = "该账号已经在线";
	                break;
	            case 3:
	            	login_result = "账号与客户端不匹配";
	                break;
	            case 4:
	            	login_result = "审核未通过";
	                break;
	            default:
	                break;
	        }
	        
	        Log.e("onRecvLoginMessage: login error", login_result);
	        Looper.prepare();
	        Toast.makeText(MainActivity.this, login_result, Toast.LENGTH_SHORT).show();
	        //关闭接收线程
	        recv.isTrue = false;
	        recv.interrupt();
	        recv = null;
	        Looper.loop();	          
		}
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);// 隐藏标题栏
		setContentView(R.layout.login);
		
		//安卓2.3以后访问网络增加内容
		StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
				.detectDiskReads()
				.detectDiskWrites()
				.detectNetwork()
				.penaltyLog()
				.build()); 
		StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
				.detectLeakedSqlLiteObjects()
				.detectLeakedClosableObjects()
				.penaltyLog()
				.penaltyDeath()
				.build());
        
		loginBtn = (Button) findViewById(R.id.Login_OK);
		mLogin_wangjimima = (TextView) findViewById(R.id.Login_wangjimima);
		mLogin_zhuce = (TextView) findViewById(R.id.Login_zhuce);
		
		//用户名和密码输入框
		mLogin_user = (EditText) findViewById(R.id.Login_user);
		mLogin_password = (EditText) findViewById(R.id.Login_password);


		loginBtn.setOnClickListener(new View.OnClickListener() {	

			@Override   
			public void onClick(View v) {
				//初始化socket
				initSocket();
				//启动接收线程
				if(recv == null){
					recv = new ReceiveMessageThread("Recv_Thread");
//					Thread th = new Thread(recv);
					recv.start();
				}
				
				String username = mLogin_user.getText().toString();
				String pwd = mLogin_password.getText().toString();

				//用户名和密码为空
				if(username.isEmpty() || pwd.isEmpty()){
					Toast.makeText(getApplicationContext(), "请输入用户名和密码",Toast.LENGTH_SHORT).show();
				}
				else{
					String str = pwd;
					byte cstr[] = str.getBytes();
					for(int i = 0;i<cstr.length;i++)
						cstr[i] = 0;
					byte strb[] = str.getBytes();
					for(int i = 0;i<str.length();i++){
						cstr[i] = strb[i];
					}
					CRC4 crc = new CRC4();
					byte b[] = Types.AES_KEY.getBytes();
					crc.Encrypt(cstr, b);
					Sockets.socket_center.SendUserinfo(username, cstr, Types.USER_TYPE_PATIENT, Types.USER_LOGIN_FLAG);
					
//					Intent intent = new Intent(MainActivity.this, MainFrame.class);
//					startActivity(intent);
				}
			}
		});

		mLogin_zhuce.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(MainActivity.this, Register.class);

				startActivity(intent);
			}
		});
		
		mLogin_wangjimima.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Toast.makeText(MainActivity.this, "忘记密码", 1).show();
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	//接收线程
	class ReceiveMessageThread extends Thread{
		boolean isTrue = true;
		public ReceiveMessageThread(String threadName){
			this.setName(threadName);
		}
		@Override
		public void run() {
			Log.e("ReceiveMessageThread", "run() ");
			//_tagThreadParams_WORKER x = new _tagThreadParams_WORKER();
			TCPSocket p = Sockets.socket_center; //从主线程中传过来
			byte recvBuf[] = new byte[10000];
			boolean pack_err = false;
			boolean isPackageHead = false;   
				
			while(isTrue){
				synchronized (this) {
					try {
						this.wait(1);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				
				try {
					p.sockClient.getInputStream().read(recvBuf);
				} catch (IOException e) {
					e.printStackTrace();
				}
				System.out.println(recvBuf.length);
				System.out.println(pack_err);
				if(pack_err == false){
					if(isPackageHead == true){
						PackHead ph = PackHead.getPackHeadInfo(recvBuf);
						if(ph.getM_Start() == Types.PACK_START_FLAG){
							isPackageHead = false;
						}
						else{
							for(int i = 0;i<recvBuf.length;i++){
								recvBuf[i] = 0;
							}
							pack_err = true;
						}
					}
					else{
						NET_PACK data = NET_PACK.getNET_PACKInfo(recvBuf);
						if(data.VerifyCRC() == data.getM_Crc()){							
							RecvPack(data);		//交给RecvPack处理
							//将recvBuf清空
							for(int i = 0;i<recvBuf.length;i++){
								recvBuf[i] = 0;
							}
							pack_err = true;
						}
						else{
							//将recvBuf清空
							for(int i = 0;i<recvBuf.length;i++){
								recvBuf[i] = 0;
							}
							pack_err = true;
						}
					}
				}		
			}
		}
	};

	//心跳包设计
	Timer heatBeatTimer;
	TimerTask heatBeatTask;
	//启动心跳包线程
	public void startHeartBeatThread(){
		heatBeatTimer = new Timer();
		heatBeatTask = new TimerTask() {
			
			@Override
			public void run() {
				HeartBeatTimeProc();
			}
		};
		heatBeatTimer.schedule(heatBeatTask, 1000, 5000);
	}
	//心跳包执行动作
	public void HeartBeatTimeProc(){
		login_socket.SendHeartBeat();
		synchronized (lock) {
			m_beatTimes++;
			if(m_beatTimes <= 2){
				m_connect_alert.setBackgroundColor(color.green);
				if(m_beatTimes == 2){
					login_socket.SendHeartBeat();
				}
			}
			else if(m_beatTimes == 3 || m_beatTimes == 4){
				m_connect_alert.setBackgroundColor(color.yellow);
				login_socket.SendHeartBeat();
			}
			else if(m_beatTimes >= 5){
				m_connect_alert.setBackgroundColor(color.red);
				login_socket.ShutSocket();
		        if (InitSocket(Types.center_Port, Types.version_IP))
		        {
		        	login_socket.ReLogin(m_login_username);
		        }
			}
		}
	}
	//接收心跳包等信息
	public void onRecvNetPack(NET_PACK data){
		int packFlag = data.getM_nFlag();
		switch(packFlag){
		//接收到的是心跳包
		case Types.HeartBeat:
			synchronized (lock) {
				m_beatTimes = 0;
			}
			break;
		default:
			break;
		}
	}
}


