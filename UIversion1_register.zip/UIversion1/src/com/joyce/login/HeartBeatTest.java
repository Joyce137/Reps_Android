package com.joyce.login;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Timer;
import java.util.TimerTask;

import com.liwei.uiversion1.R;

import android.app.Activity;
import android.os.Bundle;
import android.os.Looper;
import android.os.StrictMode;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.widget.Button;

public class HeartBeatTest extends Activity {
	//心跳包相关
	private static Object lock = new Object(); // static确保只有一把锁
	int m_beatTimes = 0;
	public TCPSocket login_socket = Sockets.socket_center;
	//显示网络状况
	private Button m_connect_alert;
	public ReceiveMessageThread recv = null;
	HeartBeatThread heart = null;
	//InitSocket
	public boolean InitSocket(int DefaultPort, String DefaultIP){
		Log.e("InitSocket", "0");
		InetAddress addr = null;
		try {
			Log.e("InitSocket", "1");
			addr = InetAddress.getByName(DefaultIP);
			login_socket.sockClient = new Socket(addr, DefaultPort);
			
			return true;
		} catch (UnknownHostException e) {
			Log.e("InitSocket", "2");
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			Log.e("InitSocket", "3");
			e.printStackTrace();
			return false;
		}
	}
		
	public void initSocket() {
		 if (!InitSocket(Types.center_Port, Types.version_IP))
		        if (!InitSocket(Types.center_Port, Types.version_IP))
		            if (!InitSocket(Types.center_Port, Types.version_IP))
		            {
		                System.out.println("网络故障，请稍后重试");
		                return;
		            }
		 Log.e("initSocket", "initSocket成功！");
	}
	
	//RecvPack
	public void RecvPack(NET_PACK data){
		Log.e("RecvPack", "RecvPack------");
		//登录标志
		if(data.getM_nFlag() == Types.Login_is){
			Login_Back_Info y = Login_Back_Info.getLogin_Back_Info(data.getM_buffer());
			if(y.getRecon() == Types.USER_LOGIN_FLAG){
				//onRecvLoginMessage(data);
			}
		}
		else{
			onRecvNetPack(data);
		}
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);// 隐藏标题栏
		setContentView(R.layout.activity_main);
		
		//安卓2.3以后访问网络增加内容
		StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
				.detectDiskReads()
				.detectDiskWrites()
				.detectNetwork()
				.penaltyLog()
				.build()); 
		StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
				.detectLeakedSqlLiteObjects()
				.detectLeakedClosableObjects()
				.penaltyLog()
				.penaltyDeath()
				.build());
       
		//初始化socket
		initSocket();
		        
		//启动接收线程
		if(recv == null){
			recv = new ReceiveMessageThread("Recv_Thread");
			recv.start();
		}
		//待登录之后启动心跳包
//        login_socket.SendHeartBeat();
        startHeartBeatThread();

//		if(heart == null){
//			heart = new HeartBeatThread("HeartBeat_Thread");
//			Thread th = new Thread(heart);
//			th.start();
//		}
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	//接收线程
	class ReceiveMessageThread extends Thread{
		boolean isTrue = true;
		public ReceiveMessageThread(String threadName){
			this.setName(threadName);
		}
		TCPSocket p = Sockets.socket_center; //从主线程中传过来
		byte recvBuf[] = new byte[10000];
		boolean pack_err = false;
		boolean isPackageHead = false;
		@Override
		public void run() {
			synchronized (lock) {
				Log.e("ReceiveMessageThread", "run() ");
				//_tagThreadParams_WORKER x = new _tagThreadParams_WORKER();
							
				while(isTrue){
					synchronized (this) {
						try {
							this.wait(1);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					
					try {
						p.sockClient.getInputStream().read(recvBuf);
					} catch (IOException e) {
						e.printStackTrace();
					}
					
					if(pack_err == false){
						if(isPackageHead == true){
							PackHead ph = PackHead.getPackHeadInfo(recvBuf);
							if(ph.getM_Start() == Types.PACK_START_FLAG){
								isPackageHead = false;
							}
							else{
								for(int i = 0;i<recvBuf.length;i++){
									recvBuf[i] = 0;
								}
								pack_err = true;
							}
						}
						else{
							NET_PACK data = NET_PACK.getNET_PACKInfo(recvBuf);
							if(data.VerifyCRC() == data.getM_Crc()){							
								RecvPack(data);		//交给RecvPack处理
								//将recvBuf清空
								for(int i = 0;i<recvBuf.length;i++){
									recvBuf[i] = 0;
								}
								pack_err = true;
							}
							else{
								//将recvBuf清空
								for(int i = 0;i<recvBuf.length;i++){
									recvBuf[i] = 0;
								}
								pack_err = true;
							}
						}
					}
					else{
						//取出recvBuf前4位，即检测其flag是什么
						NET_PACK data = NET_PACK.getNET_PACKInfo(recvBuf);
						if(data.getM_Start() == Types.PACK_START_FLAG){
							//isPackageHead = true;
							pack_err = false;
						}
						else{
							byte ch = recvBuf[1];
							for(int i = 0;i<recvBuf.length;i++){
								recvBuf[i] = 0;
							}
							recvBuf[0] = ch;
							pack_err = true;
						}
					}
				}
			}
		}		
	};

	//心跳包设计
	Timer heatBeatTimer;
	TimerTask heatBeatTask1,heatBeatTask2;
	//启动心跳包线程
	public void startHeartBeatThread (){
		heatBeatTimer = new Timer();
//		heatBeatTask1 = new TimerTask() {
//			
//			@Override
//			public void run() {
//				System.out.println(m_beatTimes);
//				HeartBeatTimeProc();
//			}
//		};
		heatBeatTimer.schedule(new Job1(), 1000, 5000);
		
//		heatBeatTask2 = new TimerTask() {
//			
//			@Override
//			public void run() {
//				System.out.println("recv");
//				RecvProc();
//			}
//		};
//		heatBeatTimer.schedule(new Job2(), 1, 1);
	}
	class Job1 extends TimerTask{

		@Override
		public void run() {
			System.out.println("Job1");
			HeartBeatTimeProc();
		}
		
	}
	class Job2 extends TimerTask{

		@Override
		public void run() {
			System.out.println("Job2");
			RecvProc();
		}
		
	}
	public void RecvProc(){
		TCPSocket p = Sockets.socket_center; //从主线程中传过来
		byte recvBuf[] = new byte[10000];
		//byte[] buff = recvBuf;
		boolean pack_err = false;
		boolean isPackageHead = false;
			
		while(true){
			synchronized (this) {
				try {
					this.wait(1);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
			try {
				p.sockClient.getInputStream().read(recvBuf);
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			if(pack_err == false){
				if(isPackageHead == true){
					PackHead ph = PackHead.getPackHeadInfo(recvBuf);
					if(ph.getM_Start() == Types.PACK_START_FLAG){
						isPackageHead = false;
					}
					else{
						for(int i = 0;i<recvBuf.length;i++){
							recvBuf[i] = 0;
						}
						pack_err = true;
					}
				}
				else{
					NET_PACK data = NET_PACK.getNET_PACKInfo(recvBuf);
					if(data.VerifyCRC() == data.getM_Crc()){							
						RecvPack(data);		//交给RecvPack处理
						//将recvBuf清空
						for(int i = 0;i<recvBuf.length;i++){
							recvBuf[i] = 0;
						}
						pack_err = true;
					}
					else{
						//将recvBuf清空
						for(int i = 0;i<recvBuf.length;i++){
							recvBuf[i] = 0;
						}
						pack_err = true;
					}
				}
			}	
			else{
				//取出recvBuf前4位，即检测其flag是什么
				NET_PACK data = NET_PACK.getNET_PACKInfo(recvBuf);
				if(data.getM_nFlag() == Types.PACK_START_FLAG){
					isPackageHead = true;
					pack_err = false;
				}
				else{
					byte ch = recvBuf[1];
					for(int i = 0;i<recvBuf.length;i++){
						recvBuf[i] = 0;
					}
					recvBuf[0] = ch;
					pack_err = true;
				}
			}
		}
	}
	class HeartBeatThread extends Thread{
		boolean isTrue = true;
		public HeartBeatThread(String threadName){
			this.setName(threadName);
		}
		@Override
		public void run() {
			Log.e("HeartBeatThread", "run() ");
			while(isTrue){
				HeartBeatTimeProc();
				synchronized (this) {
					try {
						this.wait(5000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
	//心跳包执行动作
	public void HeartBeatTimeProc(){
		login_socket.SendHeartBeat();
		//synchronized (lock) {
			m_beatTimes++;
			if(m_beatTimes <= 2){
					//m_connect_alert.setBackgroundColor(color.green);
				System.out.println(m_beatTimes+"-----color.green");
				if(m_beatTimes == 2){
					login_socket.SendHeartBeat();
				}
			}
			else if(m_beatTimes == 3 || m_beatTimes == 4){
				//m_connect_alert.setBackgroundColor(color.yellow);
				System.out.println(m_beatTimes+"-----color.yellow");
				login_socket.SendHeartBeat();
			}
			else if(m_beatTimes >= 5){
				//m_connect_alert.setBackgroundColor(color.red);
				System.out.println(m_beatTimes+"-----color.red");
				login_socket.ShutSocket();
		        if (InitSocket(Types.center_Port, Types.version_IP))
		        {
		        	//login_socket.ReLogin(m_login_username);
		        }
			}
		//}
	}
	//接收心跳包等信息
	public void onRecvNetPack(NET_PACK data){
		int packFlag = data.getM_nFlag();
		switch(packFlag){
		//接收到的是心跳包
		case Types.HeartBeat:
//			synchronized (lock) {
				m_beatTimes = 0;
				System.out.println("--------0--------"+m_beatTimes);
//			}
			break;
		default:
			break;
		}
	}
}



