package com.joyce.login;

import java.io.UnsupportedEncodingException;

import android.graphics.Color;
import android.util.Log;

//定义静态类型常量
	//#define
class Types {
	//Socket相关
	public static final String AES_KEY = "Wsn406";
	public static final int center_Port = 1001;
	public static final int version_Port = 1002;
	public static final String version_IP = "123.57.231.105";//"114.214.166.134";	
	
	//数据包相关
	public static final int MAX_PACKBUFFER_SIZE = 8*1024;	//包体大小
	public static final int PACK_START_FLAG = 0x9202; 		//包头标志
	public static final int HEADPACK = 8;
	
	//心跳包相关
	public static final int HEAT_BEAT_FLAG = 0x00AA;	//心跳包标志
	public static final int HeartBeat = 0x0705; //心跳包
	public static final int RECONNTECT = 0x0729;
	public static final int USER_RECONNECT_FLAG = 0x0741;	//断线重连
	public static final int BACKCOLOR = Color.rgb(241,243,243);
	public static final int USER_ONLINE_FLAG = 0x0740;		//主页面内上线
	public static final int Off_Link = 0x0709;		// 断开会话
	
	//用户类型
	public static final int USER_TYPE_STORE = 0x0001;
	public static final int USER_TYPE_DOCTOR = 0x0000;
	public static final int USER_TYPE_PHA = 0x0002;
	public static final int USER_TYPE_PATIENT  = 0x0003;	//用户类型为患者
	
	//登录相关
	public static final int LoginUP = 0x0800;  				//登陆信息 密码和账号
	public static final int Login_is = 0x0706;  //登陆后  服务器返回的消息	
	public static final int USER_LOGIN_FLAG = 0x0739;		//初始页面登录
	
	//注册相关
	public static final int Reg_Center = 0x0707; 	//注册  消息包
	public static final int Reg_is = 0x0708; 		//注册 服务器返回的消息
		
	//用户信息相关
	public static final int REQ_USER_INFO = 0x0728;
	public static final int ForwardInfo = 0x0730;
	public static final int Mod_Pass = 0x0731;
	public static final int Mod_Info = 0x0732;
	public static final int BangDing = 0x750;		//绑定
	public static final int MODIFY_USER_INFO = 0x0756;
	
	//请求相关
	public static final int REQ_SINGLE_USER_INFO = 0x0734;
	public static final int To_User = 0x0712;		//请求链接
	public static final int MM_RECVCONNREQ = 0x0745; //自定义消息	
	
	//功能相关
	public static final int Chufang_Content = 0x0710;  	//处方内容
	public static final int PreList_Content = 0x0711;   //清单内容
	public static final int CheckChufang = 0x0713;	 	//药剂师审核通过后  发送给服务器的消息 也用Do_Control_Msg结构体
	public static final int Req_AllPharmacist = 0x0714; //请求所有药剂师
	public static final int Req_AllDoctors = 0x0747; //请求所有医生
	public static final int Req_AllSTORES  = 0x0751; //请求所有药店

	
	//文件相关
	public static final int FileFree = 500000; 		//文件指针定时器 释放时间 一秒为1000	
	public static final int FILE_MAX_BAG = 1000; 	//当发送文件的时候 每个包发送多少个字符
	public static final int FILESTRAT = 0x0801; 	//文件头
	public static final int FILEEND = 0x0802;		//文件尾
	public static final int FILETAG = 0x0803;		//文件标志
	public static final int MY_MSG = 0x0805; 		//postthread
	public static final int INFONOYES = 0x0700; 	//一些验证消息之类的标志
	public static final int FILESENDNOYES = 0x0701; //文件发送成功与否
	public static final int FileList = 0x0717;  	//文件列表
	public static final int Req_File = 0x0715; 		//请求文件
	public static final int FILE_TYPE_PIC_REG_SMALL = 0x0735; //小窗口请求资质图片
	public static final int FILE_TYPE_PRES_CHECK_REJECT = 0x0736; //审核后 拒绝的处方
	
	public static final int FILE_TYPE_CHAT_PICTURE = 0x0737; //普通会话发送的图片

	public static final int FILE_TYPE_PIC_REG = 0x0718; //用户注册资质图片
	public static final int FILE_TYPE_PRES_CHECK = 0x0720; //审核后处方
	public static final int FILE_TYPE_PRES_LOCAL_UNCHECK = 0x072a; //本地待审核处方
	public static final int FILE_TYPE_PRES_UNCHECK = 0x0721; //未审核处方
	public static final int FILE_TYPE_DOCPHA_STAMP = 0x0722;
	public static final int FILE_TYPE_HOSPITAL_STAMP = 0x0723;
	public static final int FILE_TYPE_PRELIST = 0x0727;		//清单文件
	
	public static final int MOD_FILE_TYPE_PIC_REG = 0x072b; //用户注册资质图片
	public static final int MOD_FILE_TYPE_USER_FP = 0x072c; //用户指纹
	public static final int MOD_FILE_TYPE_DOCPHA_STAMP = 0x072d;
	
	public static final int ORDER_STATUS_PRELIST = 0x0752; 
	public static final int ORDER_STATUS_CHUFANG = 0x0753;
	public static final int ORDER_STATUS_CHECKED = 0x0754;

};

//sockets
class Sockets{
	public static final TCPSocket socket_center = new TCPSocket();
}

//ERRORNO错误标志
class ErrorNo{
	public static final int SOCKET_NULL = 0X0301;
	public static final int WSAEWOULDBLOCK = 0x0302;
	public static final int DATA_NULL = 0x0303;
	public static final int MINUSVALUE = 0x0304;
}

//struct BangDingPha
class BangDingPha{
	private String username;		//char[15];
	private String pha; 			//char[15];
	private boolean yesno;
	public BangDingPha(){
		username = "";
		pha = "";
		yesno = false;
	}
	
	//与byte数组间的转换
	public static int size = 15+15+1;
	private byte buf[] = new byte[size];
	//构造并转换为byte数组
	public BangDingPha(String username,String pha, boolean yesno){
		this.username = username;
		this.pha = pha;
		this.yesno = yesno;
			
		byte[] temp;
		try {
			//username
			temp = username.getBytes("GBK");
			System.arraycopy(temp, 0, buf, 0, temp.length);
			//pha
			temp = username.getBytes();
			System.arraycopy(temp, 0, buf, 0, temp.length);
			//yesno
			byte bool_byte = (byte) (yesno==true? 0x01:0x00);
		    buf[20] = bool_byte;
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}	
	}
	//通过byte数组获取相应的对象参数
	public static BangDingPha getBangDingPhaInfo(byte[] buf){
		String username = "";
		String pha = "";
		boolean yesno = false;
		
		try {
			//username
			byte[] tempStr = new byte[15];
			System.arraycopy(buf, 0, tempStr, 0, 15);
			username = new String(tempStr, "GBK");
			
			//pha
			System.arraycopy(buf, 15, tempStr, 0, 15);
			pha = new String(tempStr, "GBK");
			
			//yesno
			byte yesnoByte = buf[30];
			yesno = (yesnoByte == 0x00) ? false : true;
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		return new BangDingPha(username, pha, yesno);
	}
	
	//返回要发送的byte数组
	public byte[] getBuf(){
		return buf;
	}
};

//struct PackHead
	//WORD m_Start
class PackHead{
	public int getM_Start() {
		return m_Start;
	}

	public void setM_Start(int m_Start) {
		this.m_Start = m_Start;
	}

	public int getM_Crc() {
		return m_Crc;
	}

	public void setM_Crc(int m_Crc) {
		this.m_Crc = m_Crc;
	}

	public int getnDataLen() {
		return nDataLen;
	}

	public void setnDataLen(int nDataLen) {
		this.nDataLen = nDataLen;
	}

	public int getM_nFlag() {
		return m_nFlag;
	}

	public void setM_nFlag(int m_nFlag) {
		this.m_nFlag = m_nFlag;
	}

	private int m_Start;		//包头标志
	private int m_Crc;
	private int nDataLen;
	private int m_nFlag;
	
	public PackHead(){
		m_Start = Types.PACK_START_FLAG;
		m_Crc = -1;
		m_nFlag = 0;
		nDataLen = 0;
	}
	
	public static int size = 2+2+2+2;
	private byte buf[] = new byte[size];
	    
	 //构造并转化
	public PackHead(int m_Start,int m_Crc,int nDataLen,int m_nFlag){
		 this.m_Start = m_Start;
		 this.m_Crc = m_Crc;
		 this.nDataLen = nDataLen;
		 this.m_nFlag = m_nFlag;
	        
		 //m_Start(2)
		 byte[] temp = Utils.shortToLH(m_Start);
		 System.arraycopy(temp, 0, buf, 0, temp.length);
	        
		 //m_Start(2)
		 temp = Utils.shortToLH(m_Crc);
		 System.arraycopy(temp, 0, buf, 2, temp.length);
	        
		 //nDataLen(2)
		 temp = Utils.shortToLH(nDataLen);
		 System.arraycopy(temp, 0, buf, 4, temp.length);
	        
		 //m_nFlag(2)
		 temp = Utils.shortToLH(m_nFlag);
		 System.arraycopy(temp, 0, buf, 6, temp.length);
	 }
	    
	//ͨbyte数组还原为对象
	public static PackHead getPackHeadInfo(byte[] buf){
		int m_Start = Types.PACK_START_FLAG;;
		int m_Crc = -1;
		int nDataLen = 0;
		int m_nFlag = 0;
	        
		byte[] temp = new byte[4];
		//m_Start
		System.arraycopy(buf, 0, temp, 0, 2);
		m_Start = Utils.vtolh(temp);
		
		//m_Crc
		System.arraycopy(buf, 2, temp, 0, 2);
		m_Crc = Utils.vtolh(temp);
		
		//nDatalen
		System.arraycopy(buf, 4, temp, 0, 2);
		nDataLen = Utils.vtolh(temp);
		
		//m_nFlag
		System.arraycopy(buf, 6, temp, 0, 2);
		m_nFlag = Utils.vtolh(temp);
		
		return new PackHead(m_Start, m_Crc, nDataLen, m_nFlag);
	}

	//返回要发送的byte数组
	public byte[] getBuf(){
		return buf;
	}
};

//struct NET_PACK						// 网络包
class NET_PACK{
	private int m_Start;		//包头标志
	private int m_Crc;
	private int nDataLen;
	private int m_nFlag;
	private byte[] m_buffer;

	public byte[] getM_buffer() {
		return m_buffer;
	}

	public void setM_buffer(byte[] m_buffer) {
		this.m_buffer = m_buffer;
	}

	public NET_PACK(){
		Reset();
	}

	public int getM_Start() {
		return m_Start;
	}

	public void setM_Start(int m_Start) {
		this.m_Start = m_Start;
	}

	public int getM_Crc() {
		return m_Crc;
	}

	public void setM_Crc(int m_Crc) {
		this.m_Crc = m_Crc;
	}

	public int getnDataLen() {
		return nDataLen;
	}

	public void setnDataLen(int nDataLen) {
		this.nDataLen = nDataLen;
	}

	public int getM_nFlag() {
		return m_nFlag;
	}

	public void setM_nFlag(int m_nFlag) {
		this.m_nFlag = m_nFlag;
	}

	public void Reset() {
		m_Start = Types.PACK_START_FLAG;
		m_Crc = -1;	
		nDataLen = 0;
		m_nFlag = 0;
	}
	
	//除了数据以外的信息size
	public static int infoSize = 2+2+2+2;
	//该pack总size
	public int size = infoSize;
	private byte buf[];
	
	//构造并转化
	public NET_PACK(int m_Crc, int nDataLen, int m_nFlag, byte[] m_buffer){
		this.m_Start = Types.PACK_START_FLAG;
		this.m_Crc = m_Crc;
		this.nDataLen = nDataLen;
		this.m_nFlag = m_nFlag;
		this.m_buffer = m_buffer;
		
		int truesize = infoSize + m_buffer.length;
		buf = new byte[truesize];
		
		//m_Start(2)
		byte[] temp = Utils.shortToLH(m_Start);
		System.arraycopy(temp, 0, buf, 0, temp.length);
	        
		//m_Crc(2)
		temp = Utils.shortToLH(m_Crc);
		System.arraycopy(temp, 0, buf, 2, temp.length);
	        
		//nDataLen(2)
		temp = Utils.shortToLH(nDataLen);
		System.arraycopy(temp, 0, buf, 4, temp.length);
	        
		//m_nFlag(2)
		temp = Utils.shortToLH(m_nFlag);
		System.arraycopy(temp, 0, buf, 6, temp.length);
		 
		//m_buffer
		System.arraycopy(m_buffer, 0, buf, 8, m_buffer.length);
	}
	//byte数组转化为类对象
	public static NET_PACK getNET_PACKInfo(byte[] buf){
		int m_Start = Types.PACK_START_FLAG;
		int m_Crc = -1;	
		int nDataLen = 0;
		int m_nFlag = 0;
		byte[] m_buffer;
		
		byte[] temp = new byte[4];
		//m_Start
		System.arraycopy(buf, 0, temp, 0, 2);
		m_Start = Utils.vtolh(temp);
		
		//m_Crc
		System.arraycopy(buf, 2, temp, 0, 2);
		m_Crc = Utils.vtolh(temp);
		
		//nDatalen
		System.arraycopy(buf, 4, temp, 0, 2);
		nDataLen = Utils.vtolh(temp);
		
		//m_nFlag
		System.arraycopy(buf, 6, temp, 0, 2);
		m_nFlag = Utils.vtolh(temp);
	
		//m_buffer
		int len = buf.length - 8;
		m_buffer = new byte[len];
		System.arraycopy(buf, 8, m_buffer, 0, len);
	
		return new NET_PACK(m_Crc, nDataLen, m_nFlag, m_buffer);
	}
	
	//返回要发送的byte数组
	public byte[] getBuf(){
		return buf;
	}
	
	//按byte加在一起，模65536，返回一个0-65535的数据设置成m_Crc
	public void CalCRC(){
		int sum = 0;
		for(int i = 0;i<nDataLen;i++){
			sum += m_buffer[i];
		}
		this.m_Crc = sum % 65536;
		byte[] temp = Utils.shortToLH(m_Crc);
		Log.e("CalCRC", "temp"+temp.length);
		System.arraycopy(temp, 0, this.buf, 2, temp.length);
	}
	
	public int VerifyCRC(){
		int sum = 0;
		Log.e("VerifyCRC", "nDataLen"+nDataLen);
		for(int i = 0;i<nDataLen;i++){
			sum += m_buffer[i];
		}
		return sum % 65536;
	}
};

//struct UserLogin
class UserLogin{
	public byte[] getKey() {
		return key;
	}

	public void setKey(byte[] key) {
		this.key = key;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}


	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getRecon() {
		return recon;
	}

	public void setRecon(int recon) {
		this.recon = recon;
	}

	private String username;		//char[20];
	private byte[] key = new byte[20];			//char[20];
	private int type;
	private int recon;
	
	public UserLogin(){
		username = "";
		for(int i = 0;i<key.length;i++){
			key[i] = 0;
		}
		type = -1;
		recon = 0;
	}
	
	public static int size = 20+20+4+4;
	private byte[] buf= new byte[size];
	//构造并转化
	public UserLogin(String username, byte[] key, int type, int recon){
		this.username = username;
		this.key = key;
		this.type = type;
		this.recon = recon;
		
		byte temp[];
		try {
			//username
			temp = username.getBytes("GBK");
			System.arraycopy(temp, 0, buf, 0, temp.length);
			//key
			temp = key;
			System.arraycopy(temp, 0, buf, 20, temp.length);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}	
		
		//type
		temp = Utils.toLH(type);
		System.arraycopy(temp, 0, buf, 40, temp.length);
		
		//recon
		temp = Utils.toLH(recon);
		System.arraycopy(temp, 0, buf, 44, temp.length);
	}
	
	//byte数组转化为类对象
	public static UserLogin getUserLoginInfo(byte[] buf){
		String username = "";
		byte key[] = new byte[20];
		int type = 0;
		int recon = 0;
		
		try {
			//username
			byte[] tempStr20 = new byte[20];
			System.arraycopy(buf, 0, tempStr20, 0, 20);
			username = new String(tempStr20, "GBK");
			
			//key
			System.arraycopy(buf, 20, key, 0, 20);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		//type
		byte[] temp = new byte[4];
		System.arraycopy(buf, 40, temp, 0, 4);
		type = Utils.vtolh(temp);
		
		//recon
		System.arraycopy(buf, 44, temp, 0, 4);
		recon = Utils.vtolh(temp);
		
		return new UserLogin(username, key, type, recon);
	}
	
	//返回要发送的byte数组
	public byte[] getBuf(){
		return buf;
	}
};

//struct Control_Msg  //一些确认信息
class Control_Msg{
	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getFlag() {
		return flag;
	}

	public void setFlag(int flag) {
		this.flag = flag;
	}

	public boolean isYesno() {
		return yesno;
	}

	public void setYesno(boolean yesno) {
		this.yesno = yesno;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	private String filename;	//char[100]
	private String username;	//char[15]:请求链接的用户:当type为true是请求，type为false的时候是返回消息   yesno是同意否
	private int flag;			//WORD Flag:什么类型的确定消息
	private boolean yesno;		//成功还是失败
	private int type;			//错误类型
		//1.登陆的时候 type = 1 密码和账号错误；2 已经在线; 3 使用错了客户端; 4 审核未过
		//2.注册的时候 type = 1 用户名已经存在；2 相关图片传送失败
		//3.链接的时候 type = 0 代表返回消息; 1 代表请求消息; 2 代码服务器同意两者链接 
	
	public Control_Msg(){
		username = "";
		username = "";
		flag = 0;
		yesno = false;
		type = 0;
	}
	
	public static int size = 100+16+2+2+4;
	private byte[] buf= new byte[size];
	//构造并转化
	public Control_Msg(String filename, String username, int flag, boolean yesno, int type){
		this.filename = filename;
		this.username = username;
		this.flag = flag;
		this.yesno = yesno;
		this.type = type;
		
		byte temp[];
		try {
			//filename
			temp = filename.getBytes("GBK");
			System.arraycopy(temp, 0, buf, 0, temp.length);
			//username
			temp = username.getBytes("GBK");
			System.arraycopy(temp, 0, buf, 100, temp.length);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}	
		
		//flag
		temp = Utils.shortToLH(flag);
		System.arraycopy(temp, 0, buf, 116, temp.length);
		
		//yesno
		byte yesnobyte = (byte) (yesno==true? 0x01:0x00);
	    buf[118] = yesnobyte;
	    
		//type
		temp = Utils.toLH(type);
		System.arraycopy(temp, 0, buf, 120, temp.length);
	}
	
	//byte数组转化为类对象
	public static Control_Msg getControl_MsgInfo(byte[] buf){
		String filename = "";
		String username = "";
		int flag = 0;
		boolean yesno = false;
		int type = 0;
		
		try {
			//filename
			byte[] tempStr100 = new byte[100];
			System.arraycopy(buf, 0, tempStr100, 0, 100);
			filename = new String(tempStr100, "GBK");
			
			//username
			byte[] tempStr15 = new byte[15];
			System.arraycopy(buf, 100, tempStr15, 0, 15);
			username = new String(tempStr15, "GBK");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		byte[] temp = new byte[4];
		//flag
		System.arraycopy(buf, 116, temp, 0, 2);
		flag = Utils.vtolh(temp);
		
		//yesno
		byte yesnoByte = buf[118];
		yesno = (yesnoByte == 0x00) ? false : true;
		
		//type
		System.arraycopy(buf, 120, temp, 0, 4);
		type = Utils.vtolh(temp);
	
		return new Control_Msg(filename, username, flag, yesno, type);
	}
	
	//返回要发送的byte数组
	public byte[] getBuf(){
		return buf;
	}
};

//struct Login_Back_Info
class Login_Back_Info{
	public int getRecon() {
		return recon;
	}

	public void setRecon(int recon) {
		this.recon = recon;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPharmacist() {
		return pharmacist;
	}

	public void setPharmacist(String pharmacist) {
		this.pharmacist = pharmacist;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public boolean isYesno() {
		return yesno;
	}

	public void setYesno(boolean yesno) {
		this.yesno = yesno;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	private String username;	//char[15];
	private String pharmacist;	//char[15];
	private String title;		//char[100];
	private boolean yesno;		//成功还是失败
	private int type;			//登陆的时候 错误类型
		//type = 1 密码和账号错误；
		//type = 2 已经在线;
		//type = 3 使用错了客户端; 
		//type = 4 审核未过
	private int recon;
	
	public Login_Back_Info(){
		username = "";
		pharmacist = "";
		title = "";
		yesno = false;
		type = 0;
		recon = -1;
	}
	
	public static int size = 15+15+100+2+4+4;
	private byte[] buf= new byte[size];
	//构造并转化
	public Login_Back_Info(String username, String pharmacist, String title, boolean yesno, int type, int recon){
		this.username = username;
		this.pharmacist = pharmacist;
		this.title = title;
		this.yesno = yesno;
		this.type = type;
		this.recon = recon;
		
		byte temp[];
		try {
			//username
			temp = username.getBytes("GBK");
			System.arraycopy(temp, 0, buf, 0, temp.length);
			//pharmacist
			temp = pharmacist.getBytes("GBK");
			System.arraycopy(temp, 0, buf, 15, temp.length);
			//title
			temp = title.getBytes("GBK");
			System.arraycopy(temp, 0, buf, 30, temp.length);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}	
		
		//yesno
		byte yesnobyte = (byte) (yesno==true? 0x01:0x00);
	    buf[130] = yesnobyte;    
		//type
		temp = Utils.toLH(type);
		System.arraycopy(temp, 0, buf, 132, temp.length);
		//recon
		temp = Utils.toLH(recon);
		System.arraycopy(temp, 0, buf, 136, temp.length);
	}
	
	//byte数组转化为类对象
	public static Login_Back_Info getLogin_Back_Info(byte[] buf){
		String username = "";
		String pharmacist = "";
		String title = "";
		boolean yesno = false;
		int type = 0;
		int recon = 0;
		
		try {
			//username
			byte[] tempStr15 = new byte[15];
			System.arraycopy(buf, 0, tempStr15, 0, 15);
			username = new String(tempStr15, "GBK");
			
			//pharmacist
			System.arraycopy(buf, 15, tempStr15, 0, 15);
			pharmacist = new String(tempStr15, "GBK");
			
			//title
			byte[] tempStr100 = new byte[100];
			System.arraycopy(buf, 30, tempStr100, 0, 100);
			pharmacist = new String(tempStr100, "GBK");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		//yesno
		byte yesnoByte = buf[130];
		yesno = (yesnoByte == 0x00) ? false : true;
		
		byte[] temp = new byte[4];
		//type
		System.arraycopy(buf, 132, temp, 0, 4);
		type = Utils.vtolh(temp);
		
		//recon
		System.arraycopy(buf, 136, temp, 0, 4);
		recon = Utils.vtolh(temp);
	
		return new Login_Back_Info(username, pharmacist, title, yesno, type, recon);
	}
	
	//返回要发送的byte数组
	public byte[] getBuf(){
		return buf;
	}	
};

//HeartBeat
class HeartBeat{
	byte[] username = new byte[15];		//char[15]
//	byte ack;				//确认字符ACK
	public HeartBeat(){
		for(int i = 0;i<username.length;i++){
			username[i] = 0;
		}
	}
	
	public static int size = 15;
	byte[] buf = new byte[size];
	
	public HeartBeat(byte[] username){
		this.username = username;
		
		//username
		System.arraycopy(username, 0, buf, 0, username.length);
	}
	
	public static HeartBeat getHeartBeatInfo(byte buf[]){
		byte[] tempStr15 = new byte[15];
		System.arraycopy(buf, 0, tempStr15, 0, 15);
		return new HeartBeat(tempStr15);
	}
	//返回要发送的byte数组
	public byte[] getBuf(){
		return buf;
	}
};

//FileInfo   ---文件包信息
class FileInfo{
	byte[] filename = new byte[100];
	byte[] shop = new byte[12];			//药店
	byte[] doctor = new byte[12];		//医生
	byte[] pharmacist = new byte[12]; 	//药剂师
	int type;		//文件类型  1.指纹，2.资质图片，3.章，4.盖医生章的处方，5.盖药剂师和医生章的处方
	int id;			//文件包id
	int flag;		//是否是文件尾包
	int start;		//文件转换为char数组好，每个报的数据从数组的那个位置开始写入
	int len;		//文件的总字符数
	int idnum;		//文件总ID数
	int content_len;
	byte[] content = new byte[Types.FILE_MAX_BAG];
	byte[] random_str = new byte[20];
	
	int size = 100+12+12+12+4+4+4+4+4+4+4+Types.FILE_MAX_BAG+20;
	
	public FileInfo(){
		content_len = Types.FILE_MAX_BAG;
	}
	//将FileInfo对象转化为byte数组
	public byte[] getFileInfoBytes(){
		byte[] buf = new byte[size];
		
		byte[] temp2 = new byte[2];
		byte[] temp4 = new byte[4];
		
		//filename
		System.arraycopy(filename, 0, buf, 0, filename.length);
		//shop
		System.arraycopy(shop, 0, buf, 100, shop.length);
		//doctor
		System.arraycopy(doctor, 0, buf, 112, doctor.length);
		//pharmacist
		System.arraycopy(pharmacist, 0, buf, 124, pharmacist.length);
		//type(2)	
		temp2 = Utils.shortToLH(type);
		System.arraycopy(temp2, 0, buf, 136, temp2.length);
		//id
		temp4 = Utils.toLH(id);
		System.arraycopy(temp4, 0, buf, 140, temp4.length);
		//flag(2)
		temp2 = Utils.shortToLH(flag);
		System.arraycopy(temp2, 0, buf, 144, temp2.length);
		//start
		temp4 = Utils.toLH(start);
		System.arraycopy(temp4, 0, buf, 148, temp4.length);
		//len
		temp4 = Utils.toLH(len);
		System.arraycopy(temp4, 0, buf, 152, temp4.length);
		//idnum
		temp4 = Utils.toLH(idnum);
		System.arraycopy(temp4, 0, buf, 156, temp4.length);
		//content_len(2)
		temp2 = Utils.shortToLH(content_len);
		System.arraycopy(temp2, 0, buf, 160, temp2.length);
		//content
		System.arraycopy(content, 0, buf, 162, Types.FILE_MAX_BAG);
		//random_str
		System.arraycopy(random_str, 0, buf, 162+Types.FILE_MAX_BAG, random_str.length);
		return buf;
	}
	
	//将byte数组转化为FileInfo类对象
	public static FileInfo getFileInfo(byte[] buf){
		FileInfo f = new FileInfo();
		byte[] filename = new byte[100];
		byte[] shop = new byte[12];			//药店
		byte[] doctor = new byte[12];		//医生
		byte[] pharmacist = new byte[12]; 	//药剂师
		short type;		//文件类型  1.指纹，2.资质图片，3.章，4.盖医生章的处方，5.盖药剂师和医生章的处方
		int id;			//文件包id
		short flag;		//是否是文件尾包
		int start;		//文件转换为char数组好，每个报的数据从数组的那个位置开始写入
		int len;		//文件的总字符数
		int idnum;		//文件总ID数
		short content_len;
		byte[] content = new byte[Types.FILE_MAX_BAG];
		byte[] random_str = new byte[20];
		
		//filename
		System.arraycopy(buf, 0, filename, 0, 100);
		f.filename = filename;
		//shop
		System.arraycopy(buf, 100, shop, 0, 12);
		f.shop = shop;
		//doctor
		System.arraycopy(buf, 112, doctor, 0, 12);
		f.doctor = doctor;
		//pharmacist
		System.arraycopy(buf, 124, pharmacist, 0, 12);
		f.pharmacist = pharmacist;
		
		byte[] temp2 = new byte[2];
		byte[] temp4 = new byte[4];
		//type
		System.arraycopy(buf, 136, temp2, 0, 2);
		type = (short) Utils.vtolh(temp2);
		f.type = type;
		//id
		System.arraycopy(buf, 138, temp4, 0, 4);
		id = Utils.vtolh(temp4);
		f.id = id;
		//flag
		System.arraycopy(buf, 142, temp2, 0, 2);
		flag = (short) Utils.vtolh(temp2);
		f.flag = flag;
		//start
		System.arraycopy(buf, 144, temp4, 0, 4);
		start = Utils.vtolh(temp4);
		f.start = start;
		//len
		System.arraycopy(buf, 148, temp4, 0, 4);
		len = Utils.vtolh(temp4);
		f.len = len;
		//idnum
		System.arraycopy(buf, 152, temp4, 0, 4);
		idnum = Utils.vtolh(temp4);
		f.idnum = idnum;
		//content_len
		System.arraycopy(buf, 156, temp2, 0, 2);
		content_len = (short) Utils.vtolh(temp2);
		f.content_len = content_len;
		//content
		System.arraycopy(buf, 158, content, 0, Types.FILE_MAX_BAG);
		f.content = content;
		//random_str
		System.arraycopy(buf, 158+Types.FILE_MAX_BAG, random_str, 0, 20);
		f.random_str = random_str;
		
		return f;
	}
};

//PostFileInfo  ---post基本文件信息到发送文件线程
class PostThread{
	byte[] filename = new byte[100];
	byte[] filepath = new byte[150];
	int type;
	
	public static int size = 100+150+4;
	byte[] buf = new byte[size];
	
	//构造函数
	public PostThread(byte[] filename, byte[] filepath, int type){
		this.filename = filename;
		this.filepath = filepath;
		this.type = type;
		
		//filename
		System.arraycopy(filename, 0, buf, 0, filename.length);
		//filepath
		System.arraycopy(filepath, 0, buf, 100, filepath.length);
		//type
		byte temp[] = Utils.toLH(type);
		System.arraycopy(temp, 0, buf, 250, temp.length);
	}
	
	//将byte数组转化为类对象
	public static PostThread getPostThread(byte[] buf){
		byte[] filename=null,filepath=null;
		int type;
		
		//filename
		System.arraycopy(buf, 0, filename, 0, 100);
		//filepath
		System.arraycopy(buf, 100, filepath, 0, 150);
		//type
		byte[] temp_int = new byte[4];
		System.arraycopy(buf, 250, temp_int, 0, 4);
		type = Utils.vtolh(temp_int);
		
		return new PostThread(filename, filepath, type);
	}
	public byte[] getBuf(){
		return buf;
	}
}

//PreList  ---预购清单文件
class PreList{
	byte[] patient  = new byte[12];		//病人姓名
	byte[] sex = new byte[5];
	byte[] age = new byte[5];
	byte[] ID = new byte[5];
	byte[] feibie = new byte[10];
	byte[] address = new byte[100];
	byte[] content = new byte[800];
	byte[] shop = new byte[12];
	byte[] doctor = new byte[12];
	byte[] pharmacist = new byte[12];
	byte[] phone = new byte[15];
	byte[] selfreport = new byte[50];	//患者自述
	byte[] filename = new byte[100];
	byte[] date = new byte[10];
	
	public static int size = 12+5+5+5+10+100+800+12+12+12+15+50+100+10;

	//将FileInfo对象转化为byte数组
	public byte[] getPreListBytes(){
		byte[] buf = new byte[size];
		//patient
		System.arraycopy(patient, 0, buf, 0, patient.length);
		//sex
		System.arraycopy(sex, 0, buf, 12, sex.length);		
		//age
		System.arraycopy(age, 0, buf, 17, age.length);
		//ID
		System.arraycopy(ID, 0, buf, 22, ID.length);
		//feibie
		System.arraycopy(feibie, 0, buf, 27, feibie.length);
		//address
		System.arraycopy(address, 0, buf, 37, address.length);
		//content
		System.arraycopy(content, 0, buf, 137, content.length);
		//shop
		System.arraycopy(shop, 0, buf, 937, shop.length);
		//doctor
		System.arraycopy(doctor, 0, buf, 949, doctor.length);
		//pharmacist
		System.arraycopy(pharmacist, 0, buf, 961, pharmacist.length);
		//phone
		System.arraycopy(phone, 0, buf, 973, phone.length);
		//selfreport
		System.arraycopy(selfreport, 0, buf, 988, selfreport.length);
		//filename
		System.arraycopy(filename, 0, buf, 1038, filename.length);
		//date
		System.arraycopy(date, 0, buf, 1138, date.length);
		return buf;
	}
	//将byte数组转化为类对象
	public static PreList getPreList(byte[] buf){
		PreList p = new PreList();
		byte[] temp = null;
		//patient
		System.arraycopy(buf, 0, temp, 0, 12);
		p.patient = temp;
		//sex
		System.arraycopy(buf, 12, temp, 0, 5);
		p.sex = temp;
		//age
		System.arraycopy(buf, 17, temp, 0, 5);
		p.age = temp;
		//ID
		System.arraycopy(buf, 22, temp, 0, 5);
		p.ID = temp;
		//feibie
		System.arraycopy(buf, 27, temp, 0, 10);
		p.feibie = temp;
		//address
		System.arraycopy(buf, 37, temp, 0, 100);
		p.address = temp;
		//content
		System.arraycopy(buf, 137, temp, 0, 800);
		p.content = temp;
		//shop
		System.arraycopy(buf, 937, temp, 0, 12);
		p.shop = temp;		
		//doctor
		System.arraycopy(buf, 949, temp, 0, 12);
		p.doctor = temp;
		//pharmacist
		System.arraycopy(buf, 961, temp, 0, 12);
		p.pharmacist = temp;
		//phone
		System.arraycopy(buf, 973, temp, 0, 15);
		p.phone = temp;
		//selfreport
		System.arraycopy(buf, 988, temp, 0, 50);
		p.selfreport = temp;
		//filename
		System.arraycopy(buf, 1038, temp, 0, 100);
		p.filename = temp;
		//date
		System.arraycopy(buf, 1138, temp, 0, 10);
		p.date = temp;
		return p;
	}
}

//ChuFang  ---处方内容
class ChuFang{
	byte[] patient  = new byte[12];		//病人姓名
	byte[] sex = new byte[5];
	byte[] age = new byte[5];
	byte[] ID = new byte[5];
	byte[] feibie = new byte[10];
	byte[] address = new byte[100];
	byte[] content = new byte[800];
	byte[] shop = new byte[12];
	byte[] doctor = new byte[12];
	byte[] pharmacist = new byte[12];
	byte[] phone = new byte[15];
	byte[] selfreport = new byte[50];	//患者自述
	byte[] filename = new byte[100];
	byte[] date = new byte[10];
	
	byte[] title = new byte[100];
	byte[] bianhao = new byte[100];
}

//Mod_PASSWORD  ---修改密码
class Mod_PASSWORD{
	byte[] name = new byte[30];
	byte[] oldPwd = new byte[30];
	byte[] newPwd = new byte[30];
}

//MSG_USER_INFO	 ---用户信息
class MSG_USER_INFO{
	byte[] sex = new byte[5];
	byte[] age = new byte[5];
	int status;		//登陆状态 0 离线；1 在线；3 忙碌
	byte[] zhicheng = new byte[20];	//职称
	byte[] realName = new byte[25];	//真实姓名
	byte[] loginName = new byte[25];//登录名 必须唯一
	byte[] keshi = new byte[50];	//科室
	int type; //用户类型 1.医生，2.药监局，3.患者，4.药剂师
	int cw;		//中西药 true:中药，false:西药
	byte[] address = new byte[100];
	byte[] shopName = new byte[100];
	byte[] doc_pha_address = new byte[100]; //医生药剂师所属单位
	int vip;
	int off;	//false：不能接受离线文件
	byte[] phone = new byte[20];	//电话
	byte[] pharmacist = new byte[12];	//关联的药剂师名称
	byte[] password = new byte[15];	
	byte[] dianzhang = new byte[15];
	byte[] caozuoyuan = new byte[15];
	byte[] ID_Num = new byte[20];
	byte[] yibao_Num = new byte[20];
	byte[] pastDiseaseHistory = new byte[200];
	
	public static int size = 5+5+2+4+20+25+25+50+4+4+100+100+100+4+4+20+12+15+15+15+20+20+200+3;
	//将MSG_USER_INFO对象转化为byte数组
	public byte[] getMSG_USER_INFOBytes(){
		byte[] buf = new byte[size];
		//sex
		System.arraycopy(sex, 0, buf, 0, sex.length);
		//age
		System.arraycopy(age, 0, buf, 5, age.length);
		//status
		byte temp[] = Utils.toLH(status);
		System.arraycopy(temp, 0, buf, 12, temp.length);
		//zhicheng
		System.arraycopy(zhicheng, 0, buf, 16, zhicheng.length);
		//realName
		System.arraycopy(realName, 0, buf, 36, realName.length);
		//loginName
		System.arraycopy(loginName, 0, buf, 61, loginName.length);
		//keshi
		System.arraycopy(keshi, 0, buf, 86, keshi.length);
		//type
		temp = Utils.toLH(type);
		System.arraycopy(temp, 0, buf, 136, temp.length);
		//cw
		temp = Utils.toLH(cw);
		System.arraycopy(temp, 0, buf, 140, temp.length);
		//address
		System.arraycopy(address, 0, buf, 144, address.length);
		//shopName
		System.arraycopy(shopName, 0, buf, 244, shopName.length);
		//doc_pha_address
		System.arraycopy(doc_pha_address, 0, buf, 344, doc_pha_address.length);
		//vip
		temp = Utils.toLH(vip);
		System.arraycopy(temp, 0, buf, 444, temp.length);
		//off
		temp = Utils.toLH(off);
		System.arraycopy(temp, 0, buf, 448, temp.length);
		//phone
		System.arraycopy(phone, 0, buf, 452, phone.length);
		//pharmacist
		System.arraycopy(pharmacist, 0, buf, 472, pharmacist.length);
		//password
		System.arraycopy(password, 0, buf, 484, password.length);
		//dianzhang
		System.arraycopy(dianzhang, 0, buf, 499, dianzhang.length);
		//caozuoyuan
		System.arraycopy(caozuoyuan, 0, buf, 514, caozuoyuan.length);
		//ID_Num
		System.arraycopy(ID_Num, 0, buf, 529, ID_Num.length);
		//yibao_Num
		System.arraycopy(yibao_Num, 0, buf, 549, yibao_Num.length);
		//pastDiseaseHistory
		System.arraycopy(pastDiseaseHistory, 0, buf, 569, pastDiseaseHistory.length);
		
		return buf;
	}
	//将byte数组转化为类对象
	public static MSG_USER_INFO getMSG_USER_INFO(byte[] buf){
		MSG_USER_INFO p = new MSG_USER_INFO();
		byte[] temp = null;
		//sex
		System.arraycopy(buf, 0, temp, 0, 5);
		p.sex = temp;
		//age
		System.arraycopy(buf, 5, temp, 0, 5);
		p.age = temp;
		//status
		byte[] temp_int = new byte[4];
		System.arraycopy(buf, 12, temp_int, 0, 4);
		p.status = Utils.vtolh(temp_int);
		//zhicheng
		System.arraycopy(buf, 16, temp, 0, 20);
		p.zhicheng = temp;
		//realName
		System.arraycopy(buf, 36, temp, 0, 25);
		p.realName = temp;
		//loginName
		System.arraycopy(buf, 61, temp, 0, 25);
		p.loginName = temp;
		//keshi
		System.arraycopy(buf, 86, temp, 0, 50);
		p.keshi = temp;
		//type
		temp_int = new byte[4];
		System.arraycopy(buf, 136, temp_int, 0, 4);
		p.type = Utils.vtolh(temp_int);
		//cw
		temp_int = new byte[4];
		System.arraycopy(buf, 140, temp_int, 0, 4);
		p.cw = Utils.vtolh(temp_int);
		//address
		System.arraycopy(buf, 144, temp, 0, 100);
		p.address = temp;
		//shopName
		System.arraycopy(buf, 244, temp, 0, 100);
		p.shopName = temp;
		//doc_pha_address
		System.arraycopy(buf, 344, temp, 0, 100);
		p.doc_pha_address = temp;
		//vip
		temp_int = new byte[4];
		System.arraycopy(buf, 444, temp_int, 0, 4);
		p.vip = Utils.vtolh(temp_int);
		//off
		temp_int = new byte[4];
		System.arraycopy(buf, 448, temp_int, 0, 4);
		p.off = Utils.vtolh(temp_int);
		//phone
		System.arraycopy(buf, 452, temp, 0, 20);
		p.phone = temp;
		//pharmacist
		System.arraycopy(buf, 472, temp, 0, 12);
		p.pharmacist = temp;
		//password
		System.arraycopy(buf, 484, temp, 0, 15);
		p.password = temp;
		//dianzhang
		System.arraycopy(buf, 499, temp, 0, 15);
		p.dianzhang = temp;
		//caozuoyuan
		System.arraycopy(buf, 514, temp, 0, 15);
		p.caozuoyuan = temp;
		//ID_Num
		System.arraycopy(buf, 529, temp, 0, 20);
		p.ID_Num = temp;
		//yibao_Num
		System.arraycopy(buf, 549, temp, 0, 20);
		p.yibao_Num = temp;
		//pastDiseaseHistory
		System.arraycopy(buf, 569, temp, 0, 200);
		p.pastDiseaseHistory = temp;
				
		return p;
	}
}

//Req_MSG_USER_INFO	---刷新状态的时候显示的用户信息
class Req_MSG_USER_INFO{
	byte[] sex = new byte[3];
	int status;		//登陆状态 0 离线；1 在线；3 忙碌
	byte[] zhicheng = new byte[20];	//职称
	byte[] realName = new byte[25];	//真实姓名
	byte[] loginName = new byte[25];//登录名 必须唯一
}

//MSG_FILE_INFO_SINGLE  ---单个文件信息
class MSG_FILE_INFO_SINGLE{
	int type; 	//文件类型
	boolean flag;	//false表示对方未接受，true表示已接受
	byte[] filename = new byte[100];
}

//REQ_FILE_INFO	 ---请求文件信息
class REQ_FILE_INFO{
	byte[] username = new byte[20];
	boolean send_recv;	//判断username为接接收者还是发送者 true为发送者
	int type;	//文件类型
}

//ReqFile 清单  资质图片  处方 等等    
class ReqFile{
	public static final int size = 0;
	int type;	//2 资质图片， 1 指纹 ， 3 章 ，4 处方 盖医生章的  5 盖药剂师章和医生章的  6 预购清单
	byte[] filename = new byte[100];
	byte[] username = new byte[12];
	
	public byte[] getReqFileBytes(){
		return null;
	}
	
	public ReqFile getReqFile(byte[] data){
		return null;
	}
}

//FpDate ---指纹日期

//ReqUserInfo
class ReqUserInfo{
	int type;
	byte[] keshi = new byte[100];
	byte[] username = new byte[12];
	boolean doc_pha;	//医生还是药剂师
}

//P2PInfo  ---聊天消息
class P2PInfo{
	byte[] username = new byte[12];
	byte[] toUsername = new byte[12];
	byte[] info = new byte[200];
}

//ModInfo  ---修改个人信息
class ModInfo{
	byte[] sex = new byte[5];
	byte[] age = new byte[5];
	byte[] zhicheng = new byte[20];	//职称
	byte[] keshi = new byte[100];	//科室
	int cw;		//中西药 true:中药，false:西药
	byte[] address = new byte[100];
	byte[] shopName = new byte[100];
	byte[] doc_pha_address = new byte[100]; //医生药剂师所属单位
	int vip;
	int off;	//false：不能接受离线文件
	byte[] phone = new byte[20];	//电话
	//byte[] pharmacist = new byte[12];	//关联的药剂师名称
	//CHAR dianzhang[15]; //店长
    //CHAR chaozuoyuan[15];
}

//ReqPha
class ReqPha{
	byte[] phaName = new byte[12];
	byte[] realName = new byte[20];
}

//ReqDoc
class ReqDoc{
	byte[] docName = new byte[12];
	byte[] realName = new byte[20];
}

//Req_Info_Username
class Req_Info_Username{
	byte[] username = new byte[12];
}

//ReqSingleUserInfo-----请求时发的包
class ReqSingleUserInfo{
	int type;
	byte[] username = new byte[12];
	boolean isPicExist;
}

//SingleUserInfo-----接收时的包
class SingleUserInfo{
	int type;
	byte[] phone = new byte[20];
	byte[] address = new byte[100];
	
	byte[] shopName = new byte[100];
	//CHAR dianzhang[15]; //店长
    //CHAR chaozuoyuan[15];
	
	byte[] realname = new byte[12];
	byte[] zhicheng = new byte[20];
	byte[] Doc_Pha_add = new byte[100];
}
