package com.joyce.login;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import com.joyce.login.FileTest.ReceiveMessageThread;
import com.joyce.login.FileTest.SendFileThread;
import com.liwei.uiversion1.R;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.Toast;


/**
 * @Description:TODO
 * @author:Joyce
 * @time:2015-11-5 下午7:55:11
 */
public class Register extends Activity {
	public static final int REG_INFO_TYPE = 0x0003;
	private Button regBtn;
	private int m_dlgType = REG_INFO_TYPE;
	private String m_picPath = null;
	public ReceiveMessageThread recv = null;
	public static SendFileThread mSendFileThread = null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);// 隐藏标题栏
		setContentView(R.layout.register);
		
		//安卓2.3以后访问网络增加内容
		StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
						.detectDiskReads()
						.detectDiskWrites()
						.detectNetwork()
						.penaltyLog()
						.build()); 
		StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
						.detectLeakedSqlLiteObjects()
						.detectLeakedClosableObjects()
						.penaltyLog()
						.penaltyDeath()
						.build());	
		initView();
		initSocket();
		//启动接收线程
		if(recv == null){
				recv = new ReceiveMessageThread("Recv_Thread");
				recv.start();
		}
				
		//开启发文件线程
		if(mSendFileThread == null){
			mSendFileThread = new SendFileThread();
			mSendFileThread.start();
		}
	}
	private void initView() {
		regBtn = (Button) findViewById(R.id.Registration_OK);
		regBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				regAction();
			}
		});
	}
	//InitSocket
	public boolean InitSocket(int DefaultPort, String DefaultIP){
		Log.e("InitSocket", "0");
		InetAddress addr = null;
		try {
			Log.e("InitSocket", "1");
			addr = InetAddress.getByName(DefaultIP);
			Sockets.socket_center.sockClient = new Socket(addr, DefaultPort);
			
			return true;
		} catch (UnknownHostException e) {
			Log.e("InitSocket", "2");
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			Log.e("InitSocket", "3");
			e.printStackTrace();
			return false;
		}
	}
		
	public void initSocket() {
		 if (!InitSocket(Types.center_Port, Types.version_IP))
		        if (!InitSocket(Types.center_Port, Types.version_IP))
		            if (!InitSocket(Types.center_Port, Types.version_IP))
		            {
		                System.out.println("网络故障，请稍后重试");
		                return;
		            }
		 Log.e("initSocket", "initSocket成功！");
	}	
	protected void regAction() {
		if(m_dlgType == REG_INFO_TYPE){
			//发送图片
			sendPhoto();
//			try {
//				wait(1000);
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
			//发送其他信息
			sendUserTextInfo();
		}
	}
	private void sendUserTextInfo() {
		String userName, userPw, storeName, phoneNum, leader, operate, province, city, street, address,IDNum,yibaoNum,pastDiseaseHistory;
		userName = "1";
		userPw = "2";
		storeName = "3";
		phoneNum = "4";
		leader = "5";
		operate = "6";
		province = "7";
		city = "8";
		street = "9";
		IDNum = "10";
		yibaoNum = "11";
		pastDiseaseHistory = "12";
		int vip = 1;
		address = province+'|'+city+'|'+'&'+street;
		if (userName.length() >= 10){
			Toast.makeText(getApplicationContext(), "名字过长",Toast.LENGTH_SHORT).show();
			return;
		}
		//。。。。。。
		MSG_USER_INFO user = new MSG_USER_INFO();
		user.loginName = userName.getBytes();
		byte[] strPW = new byte[100];
		strPW = userPw.getBytes();
		CRC4 crc4 = new CRC4();
		crc4.Encrypt(strPW, Types.AES_KEY.getBytes());
		user.password = strPW;
		user.shopName = storeName.getBytes();
		user.phone = phoneNum.getBytes();
		user.dianzhang = leader.getBytes();
		user.caozuoyuan = operate.getBytes();
		user.address = address.getBytes();
		user.realName = operate.getBytes();
		user.vip = vip;
		user.type = Types.USER_TYPE_PATIENT;
		user.phone = phoneNum.getBytes();
		
		NET_PACK p = new NET_PACK(-1, MSG_USER_INFO.size, m_dlgType == REG_INFO_TYPE?Types.Reg_Center:Types.Mod_Info, user.getMSG_USER_INFOBytes());
		p.CalCRC();
		Sockets.socket_center.SendPack(p);
	}
	private void sendPhoto() {
		String userName = "1";
		String fileName = userName+".jpg";
		m_picPath = "/sdcard2/1.jpg";
		Sockets.socket_center.SendFile(m_picPath, fileName, Types.FILE_TYPE_PIC_REG);
	}	
	//SendFile_thread
	public boolean SendFileThread(String filepath, String filename, int type){
		if(type == Types.FILE_TYPE_PRES_CHECK || type == Types.FILE_TYPE_PRES_UNCHECK
				|| type == Types.FILE_TYPE_PRES_LOCAL_UNCHECK || type == Types.FILE_TYPE_PRES_CHECK_REJECT){
			Sockets.socket_center.SendHeartBeat();
		}
		String random_str = Utils.getRandomStr();
		//判断文件是否存在并可读
		File f = new File(filepath);
		if(!f.exists()||!f.canRead()){
			return false;
		}
		
		//读取文件到filebuf中
		int size  =  (int) f.length();
		byte[] filebuf = new byte[size];
		//文件IO流
		FileInputStream reader = null;
		try {
			reader = new FileInputStream(f);
			reader.read(filebuf, 0, size);
			reader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	
		//文件拆包
		int packCount = 0;
		if(size % Types.FILE_MAX_BAG == 0){
			packCount = size / Types.FILE_MAX_BAG;
		}
		else{
			packCount = size / Types.FILE_MAX_BAG+1;
		}
		for(int i = 0;i<packCount;i++){
			//文件包设置
			FileInfo fpinfo = new FileInfo();
			fpinfo.filename = filename.getBytes();
			fpinfo.id = i+1;
			//文件结尾
			if(i == packCount - 1){
				fpinfo.flag = Types.FILEEND;
			}
			if(i == 0){
				fpinfo.flag = Types.FILESTRAT;
			}
			fpinfo.len = size;
			fpinfo.type = (short)type;
			fpinfo.start = i * Types.FILE_MAX_BAG;
			fpinfo.idnum = packCount;
			fpinfo.random_str = random_str.getBytes();
			if(i == packCount - 1){
				System.arraycopy(filebuf, i*Types.FILE_MAX_BAG,fpinfo.content, 0,  size - Types.FILE_MAX_BAG*i);
				fpinfo.content_len = (short) (size%Types.FILE_MAX_BAG);
			}
			else{
				System.arraycopy(filebuf, i*Types.FILE_MAX_BAG, fpinfo.content, 0, Types.FILE_MAX_BAG);
			}
			
			//封装成NET_PACK包
			NET_PACK p = new NET_PACK(-1,fpinfo.size,Types.FILETAG,fpinfo.getFileInfoBytes());
			p.size = NET_PACK.infoSize + fpinfo.size;
			p.CalCRC();
			
			//发送文件包
			//mFileSocket.SendPack(p);
			if(!Sockets.socket_center.SendPack(p)){
				return false;
			}
		}
		return true;
	}
	//接收文件
	public void recvFile() {
		
	}
	//RecvPack
	public void RecvPack(NET_PACK data){
		Log.e("RecvPack", "RecvPack------");
		if(data.getM_nFlag() == Types.INFONOYES){
			doControlMsg(data);
		}
	}
	
	public void doControlMsg(NET_PACK data) {
		Control_Msg msg = Control_Msg.getControl_MsgInfo(data.getM_buffer());
		if(msg.getFlag() == Types.MOD_FILE_TYPE_PIC_REG)
		{
			onRecvControlMsg(msg);
		}
		if(msg.getFlag() == Types.Reg_is){
			onRecvRegMessage(msg);
		}
	}
	
	public void onRecvRegMessage(Control_Msg msg) {
		if(msg.getFlag() == Types.Reg_is){
			Looper.prepare();
			if (msg.isYesno())
			{
				Toast.makeText(getApplicationContext(), "注册成功！", Toast.LENGTH_SHORT).show();
				
			}
			else if(msg.getType() == 1 ||msg.getType() == 2){
				if(msg.getType() == 1){
					Toast.makeText(getApplicationContext(), "用户名已存在！", Toast.LENGTH_SHORT).show();
				}
				else{
					Toast.makeText(getApplicationContext(), "图片上传失败！", Toast.LENGTH_SHORT).show();
				}
			}
			//关闭发送文件线程
			mSendFileThread.isTrue = false;
			mSendFileThread.interrupt();
			mSendFileThread = null; 
			
			//关闭接收线程
	        recv.isTrue = false;
	        recv.interrupt();
	        recv = null;  
	        
			Looper.loop();
		}
	}
	public void onRecvControlMsg(Control_Msg msg){
		if (msg.getFlag() == Types.MOD_FILE_TYPE_PIC_REG)
		{
			if (msg.isYesno())
			{
				Looper.prepare();
				Toast.makeText(getApplicationContext(), "资质图片上传成功！", Toast.LENGTH_SHORT).show();
				
				//关闭发送文件线程
				mSendFileThread.isTrue = false;
				mSendFileThread.interrupt();
				mSendFileThread = null; 
				
				//关闭接收线程
		        recv.isTrue = false;
		        recv.interrupt();
		        recv = null;  
		        
				Looper.loop();
			}
		}
	}
		
	public void showData(NET_PACK data){
		System.out.println(data.size);
	}
	//文件发送线程SendFileThread
	class SendFileThread extends Thread{
		boolean isTrue = true;
		public Handler mHandler = null; 
		@Override
		public void run() {
			TCPSocket pSocket = Sockets.socket_center;
			while(isTrue){
				synchronized (this) {
					try {
						this.wait(1);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				
				//建立消息循环
				Looper.prepare();//1、初始化Looper
	            mHandler  = new Handler(){//2、绑定handler到SendFileThread实例的Looper对象
	                @Override
					public void handleMessage (Message msg) {//3、定义处理消息的方法
	                    switch(msg.what) {
	                    case Types.MY_MSG:
	                    	PostThread p = (PostThread) msg.obj;
	                    	String filename = new String(p.filename);
	                    	String filepath = new String(p.filepath);
	                    	int type = p.type;
	                    	SendFileThread(filepath, filename, type);
	                    }
	                }
	            };
	            Looper.loop();//4、启动消息循环
			}		
		}
	};
	//接收线程
			class ReceiveMessageThread extends Thread{
				boolean isTrue = true;
				public ReceiveMessageThread(String threadName){
					this.setName(threadName);
				}
				@Override
				public void run() {
					Log.e("ReceiveMessageThread", "run() ");
					//_tagThreadParams_WORKER x = new _tagThreadParams_WORKER();
					TCPSocket p = Sockets.socket_center; //从主线程中传过来
					byte recvBuf[] = new byte[10000];
					boolean pack_err = false;
					boolean isPackageHead = false;   
						
					while(isTrue){
						synchronized (this) {
							try {
								this.wait(1);
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}
						
						try {
							p.sockClient.getInputStream().read(recvBuf);
						} catch (IOException e) {
							e.printStackTrace();
						}
						System.out.println(recvBuf.length);
						System.out.println(pack_err);
						if(pack_err == false){
							if(isPackageHead == true){
								PackHead ph = PackHead.getPackHeadInfo(recvBuf);
								if(ph.getM_Start() == Types.PACK_START_FLAG){
									isPackageHead = false;
								}
								else{
									for(int i = 0;i<recvBuf.length;i++){
										recvBuf[i] = 0;
									}
									pack_err = true;
								}
							}
							else{
								NET_PACK data = NET_PACK.getNET_PACKInfo(recvBuf);
								if(data.VerifyCRC() == data.getM_Crc()){							
									RecvPack(data);		//交给RecvPack处理
									//将recvBuf清空
									for(int i = 0;i<recvBuf.length;i++){
										recvBuf[i] = 0;
									}
									pack_err = true;
								}
								else{
									//将recvBuf清空
									for(int i = 0;i<recvBuf.length;i++){
										recvBuf[i] = 0;
									}
									pack_err = true;
								}
							}
						}		
					}
				}
			};
}
