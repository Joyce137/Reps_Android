package com.example.ustc.healthreps.repo;

/**
 * Created by CaoRuijuan on 12/21/15.
 */
public class DrugInfo {
    public String drugName;     //药品名
    public String spec;         //规格
    public String number;       //数量
    public String unit;         //单位（瓶、盒...）
}
