package com.liwei.uiversion1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.joyce.login.FileTest;
import com.liwei.uiversion1.R;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.os.Bundle;
import android.os.Environment;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class MyCamera extends Activity {

    private CameraView cv = null;// 继承surfaceView的自定义view 用于存放照相的图片
    private Camera camera; 	// 声明照相机
    private Button cameraFolder;//文件夹
    private Button cameraPhoto;	//照相
    private Button cameraOk;	//确认
    private Button cameraExit;	//关闭
    private LinearLayout linearLayout;
    private LinearLayout linearLayoutCamera;
    private String cameraPath,camereName;
    
    public static Intent cameraIntent = null;

    private List<String> listPath = new ArrayList<String>();//存放路径的list
    int i = 0;	// 删除按钮tag值，从0开始

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.camera);
        linearLayout = (LinearLayout)findViewById(R.id.linearlayout_images);
        linearLayoutCamera = (LinearLayout)findViewById(R.id.preciew);
        cameraFolder = (Button)findViewById(R.id.camera_folder);
        cameraPhoto = (Button)findViewById(R.id.camera_photo);
        cameraOk = (Button)findViewById(R.id.camera_ok);
        cameraExit = (Button)findViewById(R.id.camera_exit);

        cameraOk.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //这里就对listPath进行操作了
            	savePicture();
            }
        });
        cameraExit.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        cameraPhoto.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                camera.takePicture(null, null, picture);
            }
        });
        cameraFolder.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //打开系统图片浏览器
                Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, 1);
            }
        });

        // 打开相机
        openCamera();
    }

    //保存图片
    public void savePicture() {
    	cameraIntent = new Intent(MyCamera.this,FileTest.class);
    	Bundle bundle = new Bundle();
    	bundle.putCharSequence("photoPath",cameraPath);
    	cameraIntent.putExtras(bundle);
    	finish();
    	startActivity(cameraIntent);   	
	}

	private void getImageView(String path) {
        int j = i ++;
        final View view = getLayoutInflater().inflate(R.layout.camera_item, null);
        final ImageView imageView = (ImageView)view.findViewById(R.id.photoshare_item_image);
        final Button button = (Button)view.findViewById(R.id.photoshare_item_delete);
        try {
            imageView.setImageBitmap(getImageBitmap(path));
            button.setTag(j);// 给按钮设置一个tag，主要为listPath的下标所用
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                linearLayout.removeView(view);
                int k = Integer.parseInt(button.getTag().toString());
                listPath.set(k, "NOIMAGE");//删除一个view（图片），就将listPath中对应的下标改一下值
            }
        });

        linearLayout.addView(view);
        listPath.add(path);
    }

    // 根据路径获取图片
    private Bitmap getImageBitmap(String path) throws FileNotFoundException, IOException{
        Bitmap bmp = null;
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, opts);
        opts.inSampleSize = ImageTools.computeSampleSize(opts, -1, 150*150);//得到缩略图
        opts.inJustDecodeBounds = false;
        try {
            bmp = BitmapFactory.decodeFile(path, opts);
        } catch (OutOfMemoryError e) {
        }
        return bmp;
    }

    //主要的surfaceView，负责展示预览图片，camera的开关
    class CameraView extends SurfaceView {

        private SurfaceHolder holder = null;

        public CameraView(Context context) {
            super(context);
            holder = this.getHolder();
            holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
            holder.addCallback(new SurfaceHolder.Callback() {
                @Override
                public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
                    Camera.Parameters parameters = camera.getParameters();
                    camera.setParameters(parameters);
                    camera.startPreview();
                }

                @SuppressLint("NewApi")
                @Override
                public void surfaceCreated(SurfaceHolder holder) {
                    camera = Camera.open();
                    try {
                        //设置camera预览的角度，因为默认图片是倾斜90度的
                        camera.setDisplayOrientation(90);
                        //设置holder主要是用于surfaceView的图片的实时预览，以及获取图片等功能
                        camera.setPreviewDisplay(holder);
                    } catch (IOException e) {
                        camera.release();
                        camera = null;
                        e.printStackTrace();
                    }
                }
                @Override
                public void surfaceDestroyed(SurfaceHolder holder) {
                    camera.stopPreview();
                    camera.release();
                    camera = null;
                }
            });
        }
    }

    private void openCamera() {
        linearLayoutCamera.removeAllViews();
        cv = new CameraView(MyCamera.this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.FILL_PARENT,
                LinearLayout.LayoutParams.FILL_PARENT);
        linearLayoutCamera.addView(cv, params);
    }

    // 回调用的picture，实现里边的onPictureTaken方法，其中byte[]数组即为照相后获取到的图片信息
    private Camera.PictureCallback picture = new Camera.PictureCallback() {

        @Override
        public void onPictureTaken(byte[] data, Camera camera) {
            File picture = new File(Environment.getExternalStorageDirectory(), System.currentTimeMillis()+".jpg");
            try {
                cameraPath = picture.getPath();
                FileOutputStream fos = new FileOutputStream(cameraPath);// 获得文件输出流
                fos.write(data);// 写入文件
                fos.close();// 关闭文件流
                openCamera();// 重新打开相机
                getImageView(cameraPath);// 获取照片
            } catch (Exception e) {

            }
        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK){
            if(requestCode == 1){
                getImageView(ImageTools.getAbsoluteImagePath(data.getData(),MyCamera.this));
            }
        }
    }
}
