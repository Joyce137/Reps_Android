package com.joyce.login;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;

import com.joyce.login.FileTest.SendFileThread;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;


class _tagThreadParams_WORKER{
	TCPSocket p;	//类指针，用于调用类中的函数
	int nThreadNo;	//线程编号
}

class TCPSocket {
	public Socket sockClient;
	public String center_IP;
	String username;
	
	Map<String, byte[]>filenametofile;
	Map<String, Set<Integer>>filenametoid;
	Set<String> fail_filename;
	
	//构造函数
	public TCPSocket(){
		
	}
	
	//ReceiveMessageThread
	public static NET_PACK ReceiveMessageThread(Socket socket, int len, int timeout){
		if(socket==null || len <0)
		{
			System.out.println("Socket 为空 !");
			return null;
		}
		byte[] receive = new byte[len];
		try {
			socket.setSoTimeout(timeout);
			socket.getInputStream().read(receive);
		} catch (IOException e) {
			e.printStackTrace();
		}
		NET_PACK p = NET_PACK.getNET_PACKInfo(receive);
		return p;
	}
	

	//SendPack
	public boolean SendPack(NET_PACK data){
		int flag = data.getM_Start();
		//循环发送
		while(true){
			int retVal;
			retVal = sendMsg(sockClient,data.getBuf(),data.size,flag);
			if(retVal != 1){
				Log.e("SendPack","SendPack: "+retVal);
				return false;
			}
			Log.e("SendPack","Yes__SendPack: "+retVal);
			return true;
		}
	}
	
	//sendMsg
	//==C语言 int send( SOCKET s,   const char FAR *buf,   int len,   int flags );
	public int sendMsg(Socket socket, byte[] data, int len, int flags){
		int resultno = 1;
		if(socket == null){
			Log.e("SendMsg","SendMsg: +ErrorNo.SOCKET_NULL");
			return ErrorNo.SOCKET_NULL;
		}
		if(data == null){
			Log.e("SendMsg","SendMsg: +ErrorNo.DATA_NULL");
			return ErrorNo.DATA_NULL;
		}
		if(len < 0){
			Log.e("SendMsg","SendMsg: +ErrorNo.MINUSVALUE");
			return ErrorNo.MINUSVALUE;
		}
		
		int available=0;
		try {
			if((available=socket.getInputStream().available())>=0){
				socket.getInputStream().skip(available);
			}	
			
 			socket.getOutputStream().write(data);
			socket.getOutputStream().flush();		
		} catch (IOException e) {
			e.printStackTrace();
		}
		Log.e("SendMsg","SendMsg: "+resultno);
		return resultno;
	}
	
	
	//ShutSocket
	public void ShutSocket(){
		if(!sockClient.isClosed()){
			try {
				sockClient.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}	
		sockClient = null;// 终止对套接字库的使用
	}
	
	//ShutConnect
	public void ShutConnect(){
		if(!sockClient.isConnected()){
			try {
				sockClient.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	//SendHeartBeat
	public boolean SendHeartBeat(){
		username = "store1";
		Log.e("HearBeat", "SendHeartBeat()");
		if(username.length() == 0){
			return false;
		}
		
		HeartBeat heart = new HeartBeat(username.getBytes());
		NET_PACK p = new NET_PACK(-1,HeartBeat.size,Types.HeartBeat,heart.getBuf());
		p.size = NET_PACK.infoSize + HeartBeat.size;
		p.CalCRC();
		
		if(SendPack(p)){
			//SendPack(p);
			return true;
		}
		else{
			return false;
		}
	}
	
	//Send_ControlMsg
	public void Send_ControlMsg(Control_Msg msg){
		NET_PACK p = new NET_PACK();
		p.size = NET_PACK.infoSize + Control_Msg.size;
		p.setM_nFlag(Types.INFONOYES);
		p.setnDataLen(Control_Msg.size);
		p.CalCRC();
		p.setM_buffer(msg.getBuf());
		
		SendPack(p);		
	}
	
	//Req_Off_Link
		//请求链接 或者 断开链接  yes为ture为请求
	public void Req_Off_Link(String username, boolean yes){
		Control_Msg cmsg = new Control_Msg();
		if(yes == true){
			cmsg.setFlag(Types.To_User);
		}
		else{
			cmsg.setFlag(Types.Off_Link);
		}
		cmsg.setType(1);
		cmsg.setUsername(username);
		
		Send_ControlMsg(cmsg);
	}
	
	//ReLogin
	public void ReLogin(String username){
		UserLogin user = new UserLogin();
		user.setUsername(username);
		user.setRecon(Types.USER_RECONNECT_FLAG);
		user.setKey(new byte[20]);
		
		//NET_PACK
		NET_PACK p = new NET_PACK();
		p.size = NET_PACK.infoSize + UserLogin.size;
		p.setM_nFlag(Types.LoginUP);
		p.setnDataLen(UserLogin.size);
		p.setM_buffer(user.getBuf());
		p.CalCRC();
		SendPack(p);
	}
	
	//SendUserinfo - 发送用户名和密码
	public void SendUserinfo(String username, byte[] key, int type, int flag){
		UserLogin user = new UserLogin(username, key, type, flag);
		NET_PACK p = new NET_PACK(-1, UserLogin.size, Types.LoginUP, user.getBuf());	
		p.size = NET_PACK.infoSize + UserLogin.size;
		p.CalCRC();
		SendPack(p);
	}
	
	//GetPath -- databases : 存放数据库
	public String GetPath(String type){
		Context c = MainActivity.context.getApplicationContext();
		String path = c.getDatabasePath(type).toString()+"/";
		return path;
	}
	
	//SendFile
	public boolean SendFile(String filepath, String filename, int type){
		//检查文件是否存在 
		File f = new File(filepath);
		if(!f.exists()){
			Log.e("SendFile", "文件不存在");
			return false;
		}
		PostThread pFileInfo = null;
		try {
			pFileInfo = new PostThread(filename.getBytes("GBK"), filepath.getBytes("GBK"), type);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		synchronized (this) {
			try {
				wait(5);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}	
		}
		
		SendFileThread t = FileTest.mSendFileThread;
		//发送消息，发送到这个Message内部持有的Handler对象，加入它的MessageQueue
		t.mHandler.obtainMessage(Types.MY_MSG, pFileInfo).sendToTarget();
		
		return true;
	}
	
//	//SendFileThread
//	public void SendFileThread(){
//		TCPSocket p = Sockets.socket_center;
//		Message msg = null;
//		while(true){
//			try {
//				wait(1);
//				if(msg.arg1 == Types.MY_MSG){
//					//PostFileInfo p = PostFileInfo.getBasicFileInfo(msg.getData().getByteArray(key))
//				}
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
//		
//		}
//	} 
	
	

	
	//SaveFile
	public void SaveFile(NET_PACK data){
		//临界区操作
		synchronized (this) {
			FileInfo p = FileInfo.getFileInfo(data.getM_buffer());
			int len = p.len,i,idnum = p.idnum;
			String filename = new String(p.filename);
			String random_str = new String(p.random_str);
			//Map与迭代器
			filenametofile = new HashMap<String, byte[]>();
			Iterator<Entry<String, byte[]>> iter = filenametofile.entrySet().iterator();
			
			//寻找random_str			
			while(iter.hasNext()){
				String key = (String) iter.next().getKey();
				if(key == random_str){
					break;
				}
			}			
			
			//找不到且包flag为文件开始
			if(!filenametofile.containsKey(random_str)&&p.flag == Types.FILESTRAT){
				//filenametofile处理
				byte[] file = new byte[len];
				filenametofile.put(random_str, file);
				
				Set<Integer> s = null;
				for(i = 1;i<=idnum;i++){
					if(i!=p.id){
						s.add(i);
					}
					else{
						System.arraycopy(p.content, 0, file, p.start, p.content_len);
					}
				}
				
				//filenametoid处理
				filenametoid = new HashMap<String, Set<Integer>>();
				filenametoid.put(random_str, s);
				
				if(idnum == 1){
					if(!WriteFile(p, iter.next().getValue())){
						//文件发送失败
						System.out.println("文件发送失败");
					}
					Iterator<Entry<String, Set<Integer>>> iter1 = filenametoid.entrySet().iterator();
					//寻找random_str			
					while(iter1.hasNext()){
						String key = (String) iter1.next().getKey();
						if(key == random_str){
							filenametoid.remove(iter1);
							break;
						}
					}		
					
					iter = filenametofile.entrySet().iterator();
					
					//寻找random_str			
					while(iter.hasNext()){
						String key = (String) iter.next().getKey();
						if(key == random_str){
							filenametofile.remove(iter);
							break;
						}
					}			
					return;
				}
			}
			//找到了random_str
			else{
				System.arraycopy(p.content, 0, iter.next().getValue(), p.start, p.content_len);
				Iterator<Entry<String, Set<Integer>>> iter1 = filenametoid.entrySet().iterator();
				//寻找random_str			
				while(iter1.hasNext()){
					String key = (String) iter1.next().getKey();
					if(key == random_str){
						break;
					}
				}
				//没找到
				if(iter1 == null){
					return;
				}
				if(iter1.next().getValue().contains(p.id)){
					iter1.next().getValue().remove(p.id);
				}
				if(iter1.next().getValue().size() == 0){
					if(!WriteFile(p, iter.next().getValue())){
						//文件发送失败
						System.out.println("文件发送失败");
					}
					filenametoid.remove(iter1);
					filenametofile.remove(iter);
					return;
				}
				if(p.flag == Types.FILEEND){
					filenametoid.remove(iter1);
					filenametofile.remove(iter);
					return;
				}
			}
		}
	}
	
	//WriteFile
	public boolean WriteFile(FileInfo p, byte[] file){
		String filename = new String(p.filename);
		File fp;
		String path = GetPath("file");
		if(p.type == Types.FILE_TYPE_PIC_REG || p.type == Types.FILE_TYPE_PIC_REG_SMALL){
			path += "pic\\";
			File f = new File(path);
			if(!f.exists()){
				f.mkdirs();
			}
		}
		else if(p.type == Types.FILE_TYPE_PRES_LOCAL_UNCHECK || p.type == Types.FILE_TYPE_PRES_CHECK
				||p.type == Types.FILE_TYPE_PRES_CHECK_REJECT){
			String dateTime = Sockets.socket_center.GetFileNameDate(filename);
			path += "本地文件\\";
			File f = new File(path);
			if(!f.exists()){
				f.mkdirs();
			}
			path = path + MainActivity.m_login_username+"\\";
			f = new File(path);
			if(!f.exists()){
				f.mkdirs();
			}
			
			if(p.type == Types.FILE_TYPE_PRES_LOCAL_UNCHECK)
				path += "已收处方(未审)\\";
			else if(p.type == Types.FILE_TYPE_PRES_CHECK)
				path += "已收处方(已审)\\";
			else if(p.type == Types.FILE_TYPE_PRES_CHECK_REJECT)
				path += "已收处方(拒审)\\";
			
			f = new File(path);
			if(!f.exists()){
				f.mkdirs();
			}
			path = path + dateTime + "\\";
			f = new File(path);
			if(!f.exists()){
				f.mkdirs();
			}
		}
		path += filename;
		fp = new File(path);
		//如果不存在，则创建
		if(!fp.exists()){
			try {
				fp.createNewFile();
			} catch (IOException e) {
				System.out.println("创建文件失败");
				e.printStackTrace();
			}
		}
		if(!(fp.isFile()|fp.canWrite())){
			return false;
		}
		
		//true-表示追加式写文件
		try {
			FileOutputStream fos = new FileOutputStream(fp,true);
			fos.write(file);
			fos.flush();
			fos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		//删除文件列表中的文件记录
		//????
		
		if(p.type != Types.FILE_TYPE_PIC_REG && p.type != Types.FILE_TYPE_PIC_REG_SMALL){
			if(p.type == Types.FILE_TYPE_PRES_CHECK){
				//Main_Dlg->FileStatusButtonShining(true, IDC_MFCBUTTON_MAIN_RECV);
			}
			else if(p.type == Types.FILE_TYPE_PRES_CHECK_REJECT){
				//Main_Dlg->FileStatusButtonShining(true, IDC_MFCBUTTON_MAIN_RECV_REJECT); 
			}
			else if(p.type == Types.FILE_TYPE_PRES_LOCAL_UNCHECK){
				//Main_Dlg->FileStatusButtonShining(true, IDC_MFCBUTTON_MAIN_RECV_UNAUTH);
			}
			
			//更新文件列表
			//??Main_Dlg->m_filelist_type
			
			Control_Msg cm = new Control_Msg(new String(p.filename), username, Types.Chufang_Content, true, p.type);
			Send_ControlMsg(cm);
			return true;
		}
		
		if(p.type == Types.FILE_TYPE_PIC_REG){
			//Main_Dlg->ShowInfoPicture(path);
		}
		else if(p.type == Types.FILE_TYPE_PIC_REG_SMALL){
			//Main_Dlg->clientInfoDlg
		}
		return true;
	}
	
	//FileSearch---递归获取一个目录下的所有文件路径
	public void FileSearch(String path, Vector<String> files){
		//获取文件目录
		File tf = new File(path);
		//保存当前目录下的所有文件
		File[] tfs = tf.listFiles();
		
		//判断目录下是否为空
		if(tfs == null){
			System.out.println("当前文件目录为空");
			return;
		}
		
		//递归获取
		for(File f: tfs){
			//文件夹，则添加路径继续递归
			if(f.isDirectory()){
				files.add(f.getPath());
				//调用本身，查找子目录
				FileSearch(f.getPath(), files);
			}
			else{
				//文件
				files.add(f.getPath());
			}
		}	
	}
	
	//CopyFile--边读边写
	public void CopyFile(String inputPath, String outputPath) throws IOException{
		File inputFile = new File(inputPath);
		File outputFile = new File(outputPath);
		InputStream is = null;
		OutputStream os = null;
		try {
			is = new FileInputStream(inputFile);
			os = new FileOutputStream(outputFile);
			//边读边写
			int temp = 0;
			while((temp = is.read()) != -1){
				os.write(temp);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();			
		} finally{
			is.close();
			os.close();		
		}
	}
	
	//Find_FilePath--查找path下的文件filename
	public void FindFilePath(String path, String filename,String filepath){
		//获取文件目录
		File tf = new File(path);
		//保存当前目录下的所有文件
		File[] tfs = tf.listFiles();
		//判断目录下是否为空
		if(tfs == null){
			System.out.println("当前文件目录为空");
			return;
		}
		
		//递归获取
		for(File f: tfs){
			//文件夹，则添加路径继续递归
			if(f.isDirectory()){
				path = path + f.getPath()+"\\";
				//调用本身，查找子目录
				FindFilePath(path,filename,filepath);
			}
			else{
				//文件
				filepath = f.getPath()+"\\"+filename;
			}
		}		
	}
	
	//GetFileNameDate(CString fileName)
	public String GetFileNameDate(String fileName){
		//拆分
		String[] fileNameArray = fileName.split("-");
		String dataStr = fileNameArray[4];
		
		//判断是否为时间串
		if(Utils.filterUnNumber(dataStr)==dataStr && dataStr.length() == 8){
			return dataStr;
		}
		//如果不是，则使用现在时间
		return Utils.getDate();
	}
	
	//SortFile(vector<string>& files, bool order) // order 是true是升序
	public Vector<String> SortFile(Vector<String> files, boolean order){
		for(int i = 0;i<files.size();i++){
			for(int j = i;j<files.size();j++){
				String a = files.get(i);
				String b = files.get(j);
				if(order){
					if(FilenameCompare(a, b)){
						String temp = files.get(i);
						files.set(i, files.get(j));
						files.set(j, temp);
					}
				}
				else{
					if(!FilenameCompare(a, b)){
						String temp = files.get(i);
						files.set(i, files.get(j));
						files.set(j, temp);
					}
				}
			}
		}
		return files;
	}
	
	//Filename_Compare(CString fileName, CString otherfileName)
	public boolean FilenameCompare(String filename, String otherFilename){
		String[] filenames1 = filename.split("-");
		String dateStr1 = filenames1[4];
		String timeStr1 = filenames1[5];
		
		String[] filenames2 = otherFilename.split("-");
		String dateStr2 = filenames2[4];
		String timeStr2 = filenames2[5];
		
		if((dateStr1.compareTo(dateStr2)>0)||((dateStr1.compareTo(dateStr2)==0)&&(timeStr1.compareTo(timeStr2)>=0))){
			return true;
		}
		else{
			return false;
		}
	}

	//请求文件
	//ReqSingleFile
	public void ReqSingleFile(int fileType, String userName, String fileName){
	    ReqFile fileInfo = new ReqFile();  
	    fileInfo.username = userName.getBytes();
	    fileInfo.filename = fileName.getBytes();
	    fileInfo.type = fileType;
	    NET_PACK p = new NET_PACK(-1, ReqFile.size, Types.Req_File, fileInfo.getReqFileBytes());
	    p.CalCRC();
	    SendPack(p);
	}
	
	//ReqFileList
	public void ReqFileList(int fileType, boolean send_recv, String userName){
		
	}
}