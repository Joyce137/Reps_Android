package com.joyce.login;

import android.os.Bundle;

public interface CallbackBundle {
	 abstract void callback(Bundle bundle);  
}
